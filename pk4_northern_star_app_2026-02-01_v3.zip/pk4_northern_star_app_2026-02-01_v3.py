
# pk4_northern_star_app_2026-02-01.py
# Streamlit app: Pick 4 "Northern Star" core stream ranking + Rare/Ultra-Rare engines (AAAB+AABB, AAAA)
# Notes:
# - Designed to work with LotteryPost-style exports (tab .txt or .csv) that include Date, State, Game, Results.
# - Ignores Wild Ball / Fireball / multipliers by extracting the first 4 digits like "1-2-3-4".
# - Excludes Maryland by default (toggle in sidebar).

from __future__ import annotations

import re
import math
import itertools
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Tuple, Optional, Iterable, Any

import numpy as np
import pandas as pd
import streamlit as st
import hashlib
import datetime
import json



# -------------------------
# Parsing + helpers
# -------------------------

FOUR_DIGITS_RE = re.compile(r"(\d)\s*-\s*(\d)\s*-\s*(\d)\s*-\s*(\d)")


def _bytes_of_upload(uploaded) -> bytes:
    if uploaded is None:
        return b""
    try:
        return uploaded.getvalue()
    except Exception:
        try:
            return uploaded.read()
        except Exception:
            return b""

def file_fingerprint(uploaded) -> str:
    """Stable fingerprint for an uploaded file (used to auto-recompute when data changes)."""
    data = _bytes_of_upload(uploaded)
    if not data:
        return ""
    return hashlib.sha1(data).hexdigest()

def most_recent_date(df: pd.DataFrame) -> Optional[pd.Timestamp]:
    if df is None or df.empty or "Date" not in df.columns:
        return None
    try:
        return pd.to_datetime(df["Date"]).max()
    except Exception:
        return None
def extract_pick4_digits(results: str) -> Optional[str]:
    """Return 4-digit string from LotteryPost 'Results' cell, else None."""
    if results is None or (isinstance(results, float) and np.isnan(results)):
        return None
    m = FOUR_DIGITS_RE.search(str(results))
    if not m:
        # Sometimes results can be plain "1234"
        m2 = re.search(r"\b(\d{4})\b", str(results))
        if m2:
            return m2.group(1)
        return None
    return "".join(m.groups())

def box_key(s: str) -> str:
    return "".join(sorted(s))

def structure_of_4(d4: str) -> str:
    """Return AABC / AAAB / AABB / AAAA / ABCD based on counts."""
    from collections import Counter
    c = Counter(d4)
    counts = sorted(c.values(), reverse=True)
    if counts == [4]:
        return "AAAA"
    if counts == [3,1]:
        return "AAAB"
    if counts == [2,2]:
        return "AABB"
    if counts == [2,1,1]:
        return "AABC"
    return "ABCD"

def canonical_core_key(core: str) -> str:
    core = re.sub(r"\D", "", str(core))
    if len(core) == 3:
        return "".join(sorted(core))
    raise ValueError("Core must be 3 digits like 389")

def members_from_core(core_key: str, structure: str) -> List[str]:
    """Return box members (4-digit strings) for a 3-digit core, for a given structure."""
    core_key = canonical_core_key(core_key)
    a, b, c = list(core_key)
    if structure == "AABC":
        # Doubles for a 3-digit core: repeat one digit, include the other two once
        return [a+a+b+c, b+b+a+c, c+c+a+b]
    if structure == "AAAB":
        # Triples: one digit x3 + one other digit x1 => 6 members
        return [a+a+a+b, a+a+a+c, b+b+b+a, b+b+b+c, c+c+c+a, c+c+c+b]
    if structure == "AABB":
        # Double-doubles: choose two digits x2 => 3 members
        return [a+a+b+b, a+a+c+c, b+b+c+c]
    if structure == "AAAA":
        return [a*4, b*4, c*4]
    raise ValueError("Unsupported structure for core members: " + structure)

def try_read_tablelike(uploaded) -> pd.DataFrame:
    """
    Accept .csv or LotteryPost tab .txt.
    Expected columns (any case): Date, State, Game, Results (or Result/Winning Numbers).
    """
    if uploaded is None:
        return pd.DataFrame()

    name = getattr(uploaded, "name", "") or ""
    # try csv first
    try:
        df = pd.read_csv(uploaded)
        if df.shape[1] == 1:
            raise ValueError("Looks like 1-column; try tab.")
    except Exception:
        uploaded.seek(0)
        df = pd.read_csv(uploaded, sep="\t", header=None)
        # try to name columns if 4+ cols
        if df.shape[1] >= 4:
            df = df.iloc[:, :4]
            df.columns = ["Date", "State", "Game", "Results"]
        else:
            # fallback
            df.columns = [f"col_{i}" for i in range(df.shape[1])]

    # normalize column names
    colmap = {c.lower().strip(): c for c in df.columns}
    def pick(*cands):
        for c in cands:
            if c in colmap:
                return colmap[c]
        return None

    date_col = pick("date")
    state_col = pick("state")
    game_col = pick("game")
    results_col = pick("results", "result", "winning numbers", "winning_numbers", "winningnumbers")

    if date_col is None or state_col is None or game_col is None or results_col is None:
        # best-effort: if there are exactly 4 columns, assume those
        if df.shape[1] >= 4:
            df = df.iloc[:, :4].copy()
            df.columns = ["Date", "State", "Game", "Results"]
        else:
            raise ValueError("Could not detect Date/State/Game/Results columns.")
    else:
        df = df.rename(columns={
            date_col: "Date",
            state_col: "State",
            game_col: "Game",
            results_col: "Results",
        })

    # parse date
    df["Date"] = pd.to_datetime(df["Date"], errors="coerce")
    df = df[df["Date"].notna()].copy()

    # parse results
    df["Pick4"] = df["Results"].map(extract_pick4_digits)
    df = df[df["Pick4"].notna()].copy()

    df["Structure"] = df["Pick4"].map(structure_of_4)
    df["Box"] = df["Pick4"].map(box_key)
    df["Stream"] = df["State"].astype(str).str.strip() + " | " + df["Game"].astype(str).str.strip()
    return df


# -------------------------
# Local history store (optional, updateable)
# -------------------------

def _parquet_engine() -> Optional[str]:
    """Return available parquet engine name, or None."""
    try:
        import pyarrow  # type: ignore
        return "pyarrow"
    except Exception:
        try:
            import fastparquet  # type: ignore
            return "fastparquet"
        except Exception:
            return None

def _store_dir() -> Path:
    """Folder for local persisted data (keeps daily app fast)."""
    try:
        base = Path(__file__).resolve().parent  # type: ignore[name-defined]
    except Exception:
        base = Path.cwd()
    d = base / "pk4_local_store"
    d.mkdir(parents=True, exist_ok=True)
    return d

def _store_paths() -> Tuple[Path, Path, str]:
    """(data_path, meta_path, kind) where kind is 'parquet' or 'csv'."""
    eng = _parquet_engine()
    if eng:
        data_path = _store_dir() / "history_store.parquet"
        kind = "parquet"
    else:
        data_path = _store_dir() / "history_store.csv"
        kind = "csv"
    meta_path = _store_dir() / "history_store_meta.json"
    return data_path, meta_path, kind

def load_history_store() -> Tuple[pd.DataFrame, Dict[str, Any], str]:
    data_path, meta_path, kind = _store_paths()
    meta: Dict[str, Any] = {}
    if meta_path.exists():
        try:
            meta = json.loads(meta_path.read_text(encoding="utf-8"))
        except Exception:
            meta = {}
    if not data_path.exists():
        return pd.DataFrame(), meta, kind

    try:
        if kind == "parquet":
            df = pd.read_parquet(data_path)  # requires pyarrow/fastparquet
        else:
            df = pd.read_csv(data_path)
    except Exception:
        return pd.DataFrame(), meta, kind

    # Re-normalize to expected schema
    try:
        df["Date"] = pd.to_datetime(df["Date"], errors="coerce")
    except Exception:
        pass
    return df, meta, kind

def save_history_store(df: pd.DataFrame, meta: Dict[str, Any]) -> Tuple[str, str]:
    """Persist df + meta. Returns (kind, path)."""
    data_path, meta_path, kind = _store_paths()
    try:
        if kind == "parquet":
            df.to_parquet(data_path, index=False)
        else:
            df.to_csv(data_path, index=False)
    except Exception:
        # If parquet write fails, fall back to CSV
        kind = "csv"
        data_path = _store_dir() / "history_store.csv"
        df.to_csv(data_path, index=False)

    try:
        meta_path.write_text(json.dumps(meta, indent=2, default=str), encoding="utf-8")
    except Exception:
        pass
    return kind, str(data_path)

def merge_new_history(existing: pd.DataFrame, incoming: pd.DataFrame) -> Tuple[pd.DataFrame, int]:
    """Merge incoming into existing with dedupe. Returns (merged, new_rows_added)."""
    if existing is None or existing.empty:
        merged = incoming.copy()
        return merged, len(merged)

    if incoming is None or incoming.empty:
        return existing.copy(), 0

    # Ensure comparable dtypes
    for col in ["Date", "State", "Game", "Results", "Pick4", "Structure", "Box", "Stream"]:
        if col in existing.columns and col in incoming.columns:
            if col == "Date":
                existing[col] = pd.to_datetime(existing[col], errors="coerce")
                incoming[col] = pd.to_datetime(incoming[col], errors="coerce")
            else:
                existing[col] = existing[col].astype(str)
                incoming[col] = incoming[col].astype(str)

    before = len(existing)
    merged = pd.concat([existing, incoming], ignore_index=True)

    # Dedupe key: Date + Stream + Pick4 (order-invariant)
    key_cols = [c for c in ["Date", "Stream", "Pick4"] if c in merged.columns]
    if key_cols:
        merged = merged.drop_duplicates(subset=key_cols, keep="last")
    else:
        merged = merged.drop_duplicates(keep="last")

    after = len(merged)
    new_rows = max(0, after - before)
    return merged, new_rows

def purge_history(df: pd.DataFrame, keep_days: int = 1095) -> Tuple[pd.DataFrame, int]:
    """Keep only the most recent keep_days based on max Date. Returns (df, purged_rows)."""
    if df is None or df.empty or "Date" not in df.columns:
        return df, 0
    df = df.copy()
    df["Date"] = pd.to_datetime(df["Date"], errors="coerce")
    df = df[df["Date"].notna()].copy()
    max_date = df["Date"].max()
    cutoff = max_date - pd.Timedelta(days=keep_days)
    before = len(df)
    df = df[df["Date"] >= cutoff].copy()
    purged = max(0, before - len(df))
    return df, purged


# -------------------------
# Stats + ranking
# -------------------------

@dataclass
class RankConfig:
    window_days: int = 180
    top_base: int = 12
    due_from_rank: int = 13
    due_to_rank: int = 60
    top_due: int = 8

def within_last_days(df: pd.DataFrame, days: int) -> pd.DataFrame:
    if df.empty:
        return df
    max_date = df["Date"].max()
    cutoff = max_date - pd.Timedelta(days=days)
    return df[df["Date"] >= cutoff].copy()

def compute_core_hits(df: pd.DataFrame, core: str, structures: Iterable[str]) -> pd.DataFrame:
    """
    Return df subset containing only rows that are hits for the core, for the chosen structures.
    We match by Box membership, so order doesn't matter.
    """
    core = canonical_core_key(core)
    boxes = set()
    for s in structures:
        for mem in members_from_core(core, s):
            boxes.add(box_key(mem))
    return df[df["Box"].isin(boxes)].copy()

def stream_summary(df_all: pd.DataFrame, df_hits: pd.DataFrame, window_days: int) -> pd.DataFrame:
    """
    For each stream, compute:
    - draws_window, hits_window, hits_per_week_window
    - days_since_last_hit_window (based on df_hits within full history)
    """
    if df_all.empty:
        return pd.DataFrame(columns=[
            "Stream","DrawsWindow","HitsWindow","HitsPerWeek","LastHitDate","DaysSinceLastHit"
        ])

    dfw = within_last_days(df_all, window_days)
    max_date = df_all["Date"].max()

    draws = dfw.groupby("Stream").size().rename("DrawsWindow")
    hitsw = within_last_days(df_hits, window_days).groupby("Stream").size().rename("HitsWindow")

    # last hit date from full history (not just window) for "due"
    last_hit = df_hits.groupby("Stream")["Date"].max().rename("LastHitDate")

    out = pd.concat([draws, hitsw, last_hit], axis=1).fillna({"HitsWindow":0})
    out["HitsWindow"] = out["HitsWindow"].astype(int)
    out["DrawsWindow"] = out["DrawsWindow"].astype(int)

    weeks = max(window_days / 7.0, 1e-9)
    out["HitsPerWeek"] = out["HitsWindow"] / weeks

    out["DaysSinceLastHit"] = (max_date - out["LastHitDate"]).dt.days
    out.loc[out["LastHitDate"].isna(), "DaysSinceLastHit"] = np.nan

    out = out.reset_index().sort_values(["HitsPerWeek","HitsWindow"], ascending=False)
    out["RankPos"] = np.arange(1, len(out)+1)
    return out

def position_percentile_map(stream_stats: pd.DataFrame) -> pd.DataFrame:
    """
    Create a rank-position map (RankPos -> HitCount) + percentiles and cumulative share.
    This is what you wanted for Northern Star: positions are individual, not ranges.
    """
    if stream_stats.empty:
        return pd.DataFrame(columns=["RankPos","HitCount","HitShare","CumHitShare","HitCountPctile"])

    total_hits = stream_stats["HitsWindow"].sum()
    pos = stream_stats[["RankPos","HitsWindow"]].rename(columns={"HitsWindow":"HitCount"}).copy()
    pos["HitShare"] = (pos["HitCount"] / total_hits) if total_hits > 0 else 0.0
    pos = pos.sort_values("RankPos")
    pos["CumHitShare"] = pos["HitShare"].cumsum()

    # percentile by HitCount (higher hitcount -> higher percentile)
    pos["HitCountPctile"] = pos["HitCount"].rank(pct=True) * 100.0
    pos["HitCountPctile"] = pos["HitCountPctile"].round(1)
    pos["HitShare"] = (pos["HitShare"] * 100.0).round(2)
    pos["CumHitShare"] = (pos["CumHitShare"] * 100.0).round(2)

    return pos


def get_position_percentiles_cached(core: str, window_days: int, stream_stats: pd.DataFrame) -> pd.DataFrame:
    """Cache position percentile maps per core/window so UI tweaks don't constantly recompute.
    Cache is automatically cleared when input data changes or when the user clicks 'Recompute percentile maps now'.
    """
    cache: Dict[str, pd.DataFrame] = st.session_state.get("pos_map_cache", {})
    data_hash = st.session_state.get("data_hash_all", "")
    key = f"{core}|{window_days}|{data_hash}"

    if key in cache:
        return cache[key]

    pos_map = position_percentile_map(stream_stats)
    cache[key] = pos_map
    st.session_state["pos_map_cache"] = cache

    if not st.session_state.get("recompute_token"):
        st.session_state["recompute_token"] = datetime.datetime.now().isoformat(timespec="seconds")

    return pos_map

def bucket_recommendations(stream_stats: pd.DataFrame, cfg: RankConfig) -> Dict[str, List[str]]:
    """
    Bucket method:
    - Take Top cfg.top_base by BaseScore (HitsPerWeek).
    - From ranks cfg.due_from_rank..cfg.due_to_rank, take Top cfg.top_due by DueIndex (DaysSinceLastHit).
    """
    if stream_stats.empty:
        return {"base_top":[], "due_top":[], "combined":[]}

    s = stream_stats.copy()

    # Base top
    base = s.nsmallest(cfg.top_base, "RankPos")["Stream"].tolist()

    # Due bucket from rank range
    due_pool = s[(s["RankPos"] >= cfg.due_from_rank) & (s["RankPos"] <= cfg.due_to_rank)].copy()
    # When last-hit is NaN (never hit), treat as very due
    due_pool["DueIndex"] = due_pool["DaysSinceLastHit"].fillna(due_pool["DaysSinceLastHit"].max() if due_pool["DaysSinceLastHit"].notna().any() else 0) + 0.01
    due = due_pool.sort_values("DueIndex", ascending=False).head(cfg.top_due)["Stream"].tolist()

    combined = []
    for x in base + due:
        if x not in combined:
            combined.append(x)

    return {"base_top": base, "due_top": due, "combined": combined}

def top_dense_positions(pos_map: pd.DataFrame, top_k_positions: int = 10) -> List[int]:
    """
    Your definition: "Top30" == the Top-10 positions with most winners (HitCount),
    regardless of where those positions occur.
    """
    if pos_map.empty:
        return []
    tmp = pos_map.sort_values(["HitCount","RankPos"], ascending=[False, True]).head(top_k_positions)
    return sorted(tmp["RankPos"].tolist())

def engine_cluster_positions(df_24h_hits: pd.DataFrame, stream_stats: pd.DataFrame, top_n: int) -> List[int]:
    """
    Map 24h hits to rank positions (based on baseline rank positions in stream_stats),
    count by RankPos, return the top_n positions by 24h frequency.
    """
    if df_24h_hits.empty or stream_stats.empty:
        return []
    pos_map = dict(zip(stream_stats["Stream"], stream_stats["RankPos"]))
    df = df_24h_hits.copy()
    df["RankPos"] = df["Stream"].map(pos_map)
    df = df[df["RankPos"].notna()].copy()
    if df.empty:
        return []
    counts = df["RankPos"].value_counts().sort_values(ascending=False)
    top = counts.head(top_n).index.tolist()
    return sorted([int(x) for x in top])


# -------------------------
# Rare / Ultra-Rare engines
# -------------------------

def evaluate_rare_engine(
    df_all: pd.DataFrame,
    core: str,
    df_24h: pd.DataFrame,
    enable_r1: bool,
    enable_r2: bool,
    enable_r3: bool,
    enable_r4: bool,
    window_days_recent: int = 180,
) -> Tuple[pd.DataFrame, Dict[str, object]]:
    """
    Rare Engine checks (AAAB + AABB together):
      R1: stream is in top 20% for combined AAAB+AABB baseline rate (full history).
      R2: stream is in top 20% for combined AAAB+AABB rate in last 180 days.
      R3: the last 24h map contains ≥3 AAAB/AABB hits across ≥3 distinct streams (global condition).
      R4: last 24h AAAB/AABB hits cluster into Top-10 RankPos, and stream RankPos is in that set.
    Trigger: at least 3 of enabled checks True.

    Returns:
      - per-stream table with booleans and trigger
      - summary dict with thresholds and cluster sets
    """
    if df_all.empty:
        return pd.DataFrame(), {"error":"No history loaded."}

    core = canonical_core_key(core)
    df_hits_all = compute_core_hits(df_all, core, structures=["AAAB","AABB"])

    # Baseline stream stats
    base_stats = stream_summary(df_all, df_hits_all, window_days=min(365*5, int((df_all["Date"].max()-df_all["Date"].min()).days) or 365))
    # But we want baseline based on full history span; use hits per week in that span:
    span_days = max(int((df_all["Date"].max()-df_all["Date"].min()).days), 1)
    base_stats["HitsPerWeek_full"] = base_stats["HitsWindow"] / (span_days/7.0)
    base_stats = base_stats.sort_values(["HitsPerWeek_full","HitsWindow"], ascending=False).reset_index(drop=True)
    base_stats["RankPos_full"] = np.arange(1, len(base_stats)+1)

    # Recent stats (180d)
    recent_stats = stream_summary(df_all, df_hits_all, window_days=window_days_recent)

    # Thresholds
    def pct_threshold(series: pd.Series, pct: float) -> float:
        vals = series.dropna().values
        if len(vals)==0:
            return float("nan")
        return float(np.quantile(vals, pct))

    # R1 top 20% based on HitsPerWeek_full
    thr_r1 = pct_threshold(base_stats["HitsPerWeek_full"], 0.80)

    # R2 top 20% based on recent HitsPerWeek
    thr_r2 = pct_threshold(recent_stats["HitsPerWeek"], 0.80)

    # R3 global condition from 24h file: ≥3 hits across ≥3 distinct streams
    df_24h_core_hits = pd.DataFrame()
    top10_cluster = []
    r3_global = False
    if df_24h is not None and not df_24h.empty:
        df_24h_core_hits = compute_core_hits(df_24h, core, structures=["AAAB","AABB"])
        n_hits_24h = int(len(df_24h_core_hits))
        n_streams_24h = int(df_24h_core_hits["Stream"].nunique()) if n_hits_24h else 0
        r3_global = (n_hits_24h >= 3) and (n_streams_24h >= 3)
        # R4 cluster based on 24h file (Top-10 RankPos positions by 24h frequency)
        top10_cluster = engine_cluster_positions(
            df_24h_core_hits,
            base_stats.rename(columns={"RankPos_full":"RankPos"}).assign(RankPos=base_stats["RankPos_full"]),
            top_n=10,
        )

    # Merge per stream
    out = pd.DataFrame({"Stream": base_stats["Stream"]})
    out = out.merge(base_stats[["Stream","HitsPerWeek_full","RankPos_full"]], on="Stream", how="left")
    out = out.merge(recent_stats[["Stream","HitsPerWeek","DaysSinceLastHit","RankPos"]].rename(columns={"RankPos":"RankPos_recent"}), on="Stream", how="left")

    out["R1_top20_baseline"] = out["HitsPerWeek_full"] >= thr_r1 if enable_r1 else False
    out["R2_top20_recent"] = out["HitsPerWeek"] >= thr_r2 if enable_r2 else False
    out["R3_24h_has_3plus_across_3streams"] = r3_global if enable_r3 else False
    out["R4_24h_cluster_top10pos"] = out["RankPos_full"].isin(top10_cluster) if enable_r4 else False

    enabled_cols = [c for c, en in [
        ("R1_top20_baseline", enable_r1),
        ("R2_top20_recent", enable_r2),
        ("R3_24h_has_3plus_across_3streams", enable_r3),
        ("R4_24h_cluster_top10pos", enable_r4),
    ] if en]

    out["ChecksTrue"] = out[enabled_cols].sum(axis=1) if enabled_cols else 0
    out["RareEngine_TRIG"] = out["ChecksTrue"] >= 3 if enabled_cols else False

    out = out.sort_values(["RareEngine_TRIG","ChecksTrue","HitsPerWeek_full"], ascending=[False, False, False]).reset_index(drop=True)

    summary = {
        "thr_r1": thr_r1,
        "thr_r2": thr_r2,
        "r3_global": r3_global,
        "top10_cluster_positions": top10_cluster,
        "n_24h_core_hits": int(len(df_24h_core_hits)) if df_24h is not None else 0,
        "n_24h_core_streams": int(df_24h_core_hits["Stream"].nunique()) if df_24h is not None and not df_24h_core_hits.empty else 0,
        "span_days_full": span_days,
        "enabled_checks": enabled_cols,
    }
    return out, summary

def evaluate_ultra_rare_engine(
    df_all: pd.DataFrame,
    core: str,
    df_24h: pd.DataFrame,
    enable_q1: bool,
    enable_q2: bool,
    enable_q3: bool,
    enable_q4: bool,
) -> Tuple[pd.DataFrame, Dict[str, object]]:
    """
    Ultra-Rare Engine checks (AAAA quads for the core's digits):
      Q1: stream in top 10% for quad baseline rate (full history)
      Q2: days since last quad >= 90th percentile across streams
      Q3: last 24h has at least 1 quad anywhere (for any digit in core)
      Q4: 24h quad hits (for core) cluster into Top-5 RankPos; stream position is in that set
    Trigger: at least 2 of enabled checks True.
    """
    if df_all.empty:
        return pd.DataFrame(), {"error":"No history loaded."}

    core = canonical_core_key(core)
    df_hits_all = compute_core_hits(df_all, core, structures=["AAAA"])

    span_days = max(int((df_all["Date"].max()-df_all["Date"].min()).days), 1)
    base_stats = stream_summary(df_all, df_hits_all, window_days=min(365*5, span_days))
    base_stats["HitsPerWeek_full"] = base_stats["HitsWindow"] / (span_days/7.0)
    base_stats = base_stats.sort_values(["HitsPerWeek_full","HitsWindow"], ascending=False).reset_index(drop=True)
    base_stats["RankPos_full"] = np.arange(1, len(base_stats)+1)

    # thresholds
    def pct_threshold(series: pd.Series, pct: float) -> float:
        vals = series.dropna().values
        if len(vals)==0:
            return float("nan")
        return float(np.quantile(vals, pct))

    thr_q1 = pct_threshold(base_stats["HitsPerWeek_full"], 0.90)
    thr_q2 = pct_threshold(base_stats["DaysSinceLastHit"], 0.90)  # DaysSinceLastHit computed from last quad date

    # Q3 global 24h quad exists for any core digit
    q3_global = False
    df_24h_core_hits = pd.DataFrame()
    top5_cluster = []
    if df_24h is not None and not df_24h.empty:
        # any quad in 24h that uses one of core digits
        core_digits = set(core)
        df_24h_quads = df_24h[df_24h["Structure"]=="AAAA"].copy()
        df_24h_quads["quad_digit"] = df_24h_quads["Pick4"].str[0]
        q3_global = df_24h_quads["quad_digit"].isin(core_digits).any()
        df_24h_core_hits = compute_core_hits(df_24h, core, structures=["AAAA"])
        top5_cluster = engine_cluster_positions(df_24h_core_hits, base_stats.rename(columns={"RankPos_full":"RankPos"}).assign(RankPos=base_stats["RankPos_full"]), top_n=5)

    out = pd.DataFrame({"Stream": base_stats["Stream"]})
    out = out.merge(base_stats[["Stream","HitsPerWeek_full","DaysSinceLastHit","RankPos_full"]], on="Stream", how="left")

    out["Q1_top10_baseline"] = out["HitsPerWeek_full"] >= thr_q1 if enable_q1 else False
    out["Q2_due_p90"] = out["DaysSinceLastHit"] >= thr_q2 if enable_q2 else False
    out["Q3_24h_quad_exists"] = q3_global if enable_q3 else False
    out["Q4_24h_cluster_top5pos"] = out["RankPos_full"].isin(top5_cluster) if enable_q4 else False

    enabled_cols = [c for c, en in [
        ("Q1_top10_baseline", enable_q1),
        ("Q2_due_p90", enable_q2),
        ("Q3_24h_quad_exists", enable_q3),
        ("Q4_24h_cluster_top5pos", enable_q4),
    ] if en]

    out["ChecksTrue"] = out[enabled_cols].sum(axis=1) if enabled_cols else 0
    out["UltraRare_TRIG"] = out["ChecksTrue"] >= 2 if enabled_cols else False

    out = out.sort_values(["UltraRare_TRIG","ChecksTrue","HitsPerWeek_full"], ascending=[False, False, False]).reset_index(drop=True)

    summary = {
        "thr_q1": thr_q1,
        "thr_q2": thr_q2,
        "q3_global": q3_global,
        "top5_cluster_positions": top5_cluster,
        "n_24h_core_quad_hits": int(len(df_24h_core_hits)) if df_24h is not None else 0,
        "enabled_checks": enabled_cols,
        "span_days_full": span_days,
    }
    return out, summary


# -------------------------
# UI
# -------------------------

st.set_page_config(page_title="Pick 4 Northern Star", layout="wide")

st.markdown(
    """
<style>
/* Make data freshness panel easier to read in the sidebar */
section[data-testid="stSidebar"] .stMarkdown, 
section[data-testid="stSidebar"] .stText, 
section[data-testid="stSidebar"] .stCaption {
    font-size: 0.85rem;
}
.small-freshness {
    font-size: 0.80rem;
    line-height: 1.15rem;
}
</style>
""",
    unsafe_allow_html=True,
)


st.title("Pick 4 — Northern Star + Rare Engine (AAAB+AABB) + Ultra‑Rare (AAAA)")

with st.sidebar:
    st.header("Data")
    master_file = st.file_uploader("All‑states history file (.csv or LotteryPost .txt)", type=["csv","txt"])
    map24_file = st.file_uploader("24h map file (optional, same format)", type=["csv","txt"])

    exclude_md = st.checkbox("Exclude Maryland streams", value=True)


    st.caption("Local history store keeps daily runs fast by saving a rolling 3‑year dataset on disk.")
    use_local_store = st.checkbox("Use/maintain local history store", value=True)
    auto_merge_24h = st.checkbox("Auto‑merge 24h file into history store", value=True)
    auto_purge_3yr = st.checkbox("Auto‑purge beyond rolling 3 years", value=True)
    auto_clear_cache_if_7d = st.checkbox("Auto‑clear percentile cache if ≥7 days of new data added", value=True)

    # Percentile tools (updateable)
    if "pos_map_cache" not in st.session_state:
        st.session_state["pos_map_cache"] = {}
    if "recompute_token" not in st.session_state:
        st.session_state["recompute_token"] = ""
    if st.button("Recompute percentile maps now"):
        st.session_state["pos_map_cache"] = {}
        st.session_state["recompute_token"] = datetime.datetime.now().isoformat(timespec="seconds")
    if st.session_state.get("recompute_token"):
        st.caption(f"Percentiles last recomputed: {st.session_state['recompute_token']}")
    st.divider()

    st.header("Core selection")
    cores_raw = st.text_input("Cores (comma‑separated)", value="389")
    cores = []
    for part in [p.strip() for p in cores_raw.split(",") if p.strip()]:
        try:
            cores.append(canonical_core_key(part))
        except Exception:
            pass
    cores = sorted(list(dict.fromkeys(cores)))
    if not cores:
        st.warning("Enter at least one valid 3‑digit core like 389.")

    st.divider()
    st.header("Northern Star window")
    window_days = st.radio("Window (days)", options=[180, 365], index=0, horizontal=True)
    cfg = RankConfig(window_days=window_days)

    st.caption("Bucket method: Top 12 BaseScore (Hits/week) + Top 8 DueIndex from ranks 13–60.")

    st.divider()
    st.header("Rare Engine trigger — AAAB + AABB")
    r1 = st.checkbox("R1: Top‑20% baseline AAAB+AABB", value=True)
    r2 = st.checkbox("R2: Top‑20% recent (last window)", value=True)
    r3 = st.checkbox("R3: 24h has ≥3 AAAB/AABB hits across ≥3 streams", value=True)
    r4 = st.checkbox("R4: 24h cluster ∈ Top‑10 positions", value=True)

    st.divider()
    st.header("Ultra‑Rare trigger — AAAA")
    q1 = st.checkbox("Q1: Top‑10% quad baseline", value=True)
    q2 = st.checkbox("Q2: Due pressure ≥ P90", value=True)
    q3 = st.checkbox("Q3: 24h quad exists (core digits)", value=True)
    q4 = st.checkbox("Q4: 24h cluster ∈ Top‑5 positions", value=True)

    st.divider()
    straights_opt = st.checkbox("Generate straights shortlist (optional last)", value=False)


# Load data
# Load data (supports optional local rolling store)
df_store, store_meta, store_kind = load_history_store() if use_local_store else (pd.DataFrame(), {}, "csv")

df_all_uploaded = try_read_tablelike(master_file) if master_file else pd.DataFrame()
df_24h = try_read_tablelike(map24_file) if map24_file else pd.DataFrame()

# Apply Maryland exclusion immediately on uploaded inputs
if exclude_md and not df_all_uploaded.empty:
    df_all_uploaded = df_all_uploaded[df_all_uploaded["State"].astype(str).str.strip().str.lower() != "maryland"].copy()
if exclude_md and not df_store.empty:
    df_store = df_store[df_store["State"].astype(str).str.strip().str.lower() != "maryland"].copy()
if exclude_md and not df_24h.empty:
    df_24h = df_24h[df_24h["State"].astype(str).str.strip().str.lower() != "maryland"].copy()

store_notes: List[str] = []
days_span_new = 0

if use_local_store:
    # If user uploaded a master file, treat it as the baseline reset for the store (authoritative)
    if not df_all_uploaded.empty:
        df_all = df_all_uploaded.copy()
        store_meta = {
            "built_from_master_upload": True,
            "master_file_fingerprint": file_fingerprint(master_file),
            "built_at": datetime.datetime.now().isoformat(timespec="seconds"),
            "rows": int(len(df_all)),
            "max_date": str(pd.to_datetime(df_all["Date"]).max().date()),
            "store_kind": store_kind,
        }
        kind, path = save_history_store(df_all, store_meta)
        store_notes.append(f"History store reset from uploaded master file → saved as {kind.upper()} at {path}")
        df_store = df_all.copy()

    # If store exists (or was just created), use it as df_all
    if df_all_uploaded.empty and not df_store.empty:
        df_all = df_store.copy()
        store_notes.append("Using persisted local history store (no master file uploaded this run).")
    elif df_all_uploaded.empty and df_store.empty:
        df_all = pd.DataFrame()
    else:
        # df_all set above from upload
        pass

    # Merge 24h into store if enabled
    if auto_merge_24h and not df_24h.empty:
        before_max = pd.to_datetime(df_all["Date"]).max() if (df_all is not None and not df_all.empty) else None
        merged, new_rows = merge_new_history(df_all, df_24h)
        if new_rows > 0:
            after_max = pd.to_datetime(merged["Date"]).max()
            if before_max is not None and pd.notna(before_max) and pd.notna(after_max):
                days_span_new = (after_max.date() - before_max.date()).days
            df_all = merged
            store_notes.append(f"Auto‑merged {new_rows} new rows from 24h file into history store.")
        else:
            store_notes.append("No new rows found in 24h file (already present).")

    # Purge to rolling 3 years
    if auto_purge_3yr and df_all is not None and not df_all.empty:
        df_all, purged = purge_history(df_all, keep_days=1095)
        if purged > 0:
            store_notes.append(f"Purged {purged} rows older than rolling 3 years.")

    # Persist final merged store
    if df_all is not None and not df_all.empty:
        store_meta = store_meta or {}
        store_meta.update({
            "updated_at": datetime.datetime.now().isoformat(timespec="seconds"),
            "rows": int(len(df_all)),
            "max_date": str(pd.to_datetime(df_all["Date"]).max().date()),
            "store_kind": store_kind,
            "auto_merge_24h": bool(auto_merge_24h),
            "auto_purge_3yr": bool(auto_purge_3yr),
        })
        kind, path = save_history_store(df_all, store_meta)
        store_meta["_path"] = path
        store_meta["_kind"] = kind
else:
    # No local store: use uploaded file only
    df_all = df_all_uploaded.copy()

# Optional: auto-clear percentile cache if new data spans >= 7 days
if use_local_store and auto_clear_cache_if_7d and days_span_new >= 7:
    st.session_state["pos_map_cache"] = {}
    st.session_state["recompute_token"] = ""
    store_notes.append("Cleared percentile cache automatically (≥7 days of new data added).")


# Auto-clear cached percentile maps when input data changes
all_hash = file_fingerprint(master_file)
map_hash = file_fingerprint(map24_file)
if "data_hash_all" not in st.session_state:
    st.session_state["data_hash_all"] = ""
if "data_hash_24h" not in st.session_state:
    st.session_state["data_hash_24h"] = ""

if all_hash and all_hash != st.session_state["data_hash_all"]:
    st.session_state["pos_map_cache"] = {}
    st.session_state["data_hash_all"] = all_hash
    st.session_state["recompute_token"] = ""  # will refresh on next compute
if map_hash != st.session_state["data_hash_24h"]:
    st.session_state["pos_map_cache"] = {}
    st.session_state["data_hash_24h"] = map_hash
    st.session_state["recompute_token"] = ""

# Show data freshness (so the instructions never need updating)
last_all = most_recent_date(df_all)
last_24 = most_recent_date(df_24h)

today = datetime.date.today()
def _age_days(ts: Optional[pd.Timestamp]) -> Optional[int]:
    if ts is None or pd.isna(ts):
        return None
    try:
        d = pd.to_datetime(ts).date()
        return (today - d).days
    except Exception:
        return None

st.sidebar.markdown("### Data freshness")
if last_all is not None and not pd.isna(last_all):
    st.sidebar.markdown(
        f'<div class="small-freshness"><b>History most recent date:</b> {pd.to_datetime(last_all).date()} '
        f'(age: {_age_days(last_all)} days)</div>',
        unsafe_allow_html=True,
    )
else:
    st.sidebar.markdown('<div class="small-freshness"><b>History most recent date:</b> (not found)</div>', unsafe_allow_html=True)

if map24_file is None:
    st.sidebar.markdown('<div class="small-freshness"><b>24h map file:</b> (not uploaded)</div>', unsafe_allow_html=True)
elif last_24 is not None and not pd.isna(last_24):
    st.sidebar.markdown(
        f'<div class="small-freshness"><b>24h map most recent date:</b> {pd.to_datetime(last_24).date()} '
        f'(age: {_age_days(last_24)} days)</div>',
        unsafe_allow_html=True,
    )
else:
    st.sidebar.markdown('<div class="small-freshness"><b>24h map most recent date:</b> (not found)</div>', unsafe_allow_html=True)

# Local store status + export (human readable)
if use_local_store:
    kind = store_meta.get("_kind") or store_meta.get("store_kind") or store_kind
    path = store_meta.get("_path", "")
    rows = store_meta.get("rows", None)
    maxd = store_meta.get("max_date", None)
    st.sidebar.markdown("**Local history store:**")
    st.sidebar.caption(f"Format: {str(kind).upper()}  |  Rows: {rows if rows is not None else '—'}  |  Max date: {maxd if maxd else '—'}")
    if path:
        st.sidebar.caption(f"Location: {path}")
    if _parquet_engine() is None:
        st.sidebar.caption("Tip: Install `pyarrow` to enable Parquet automatically. CSV remains fully accurate (just larger).")
    if store_notes:
        st.sidebar.caption("Updates this run:")
        for note in store_notes[-6:]:
            st.sidebar.caption(f"• {note}")
    if df_all is not None and not df_all.empty:
        st.sidebar.download_button(
            "Download local history store (CSV)",
            data=df_all.to_csv(index=False).encode("utf-8"),
            file_name="pk4_history_store.csv",
            mime="text/csv",
        )

# Gate: require at least one valid history source
if df_all is None or df_all.empty:
    st.info("Upload your all‑states history file (or enable the local history store and run once to create it).")
    st.stop()

if df_all.empty:
    st.error("Could not parse your history. Make sure it contains Date, State, Game, Results (LotteryPost export).")
    st.stop()

# One place to show dataset info
colA, colB, colC = st.columns(3)
with colA:
    st.metric("Rows (draws)", f"{len(df_all):,}")
with colB:
    st.metric("Streams", f"{df_all['Stream'].nunique():,}")
with colC:
    st.metric("Date span", f"{df_all['Date'].min().date()} → {df_all['Date'].max().date()}")

st.divider()

tabs = st.tabs([f"Core {c}" for c in cores])

for core, tab in zip(cores, tabs):
    with tab:
        st.subheader(f"Core {core}")

        # Base (AABC doubles) core hits + stream ranking
        df_hits_core = compute_core_hits(df_all, core, structures=["AABC"])
        stats = stream_summary(df_all, df_hits_core, window_days=cfg.window_days)

        # Northern Star position map + Top30 (Top-10 positions by HitCount)
        pos_map = get_position_percentiles_cached(core, cfg.window_days, stats)
        top30_positions = top_dense_positions(pos_map, top_k_positions=10)
        capture = None
        if not pos_map.empty and pos_map["HitCount"].sum() > 0:
            capture = pos_map[pos_map["RankPos"].isin(top30_positions)]["HitCount"].sum() / pos_map["HitCount"].sum() * 100.0

        # Bucket recommendations
        buckets = bucket_recommendations(stats, cfg)

        left, right = st.columns([1.3, 1.0])

        with left:
            st.markdown("### Stream ranking (AABC doubles)")
            show = stats[["RankPos","Stream","HitsWindow","HitsPerWeek","DaysSinceLastHit"]].copy()
            show = show.rename(columns={
                "HitsWindow":"Hits",
                "HitsPerWeek":"Hits/week",
                "DaysSinceLastHit":"Days since last hit",
            })
            st.dataframe(show, use_container_width=True, hide_index=True)

        with right:
            st.markdown("### Northern Star buckets")
            st.write("**Top 12 (BaseScore)**")
            st.write("\n".join([f"- {s}" for s in buckets["base_top"]]) if buckets["base_top"] else "_None_")

            st.write("**Top 8 DueIndex (Ranks 13–60)**")
            st.write("\n".join([f"- {s}" for s in buckets["due_top"]]) if buckets["due_top"] else "_None_")

            st.write("**Combined list**")
            st.write("\n".join([f"- {s}" for s in buckets["combined"]]) if buckets["combined"] else "_None_")

            if straights_opt:
                st.markdown("### Straights shortlist (optional)")
                members = members_from_core(core, "AABC")
                st.caption("All permutations are shown (not ranked yet).")
                for m in members:
                    perms = sorted(set("".join(p) for p in itertools.permutations(m)))
                    st.write(f"**Box {box_key(m)}** → {', '.join(perms[:24])}" + (" …" if len(perms) > 24 else ""))

        st.divider()

        with st.expander("Northern Star percentile stats (rank‑position map 1..N)", expanded=False):
            st.caption("Each position is labeled individually. 'Top30' is the Top‑10 positions by winner count in this window.")
            if pos_map.empty:
                st.info("No data for this core in the selected window.")
            else:
                st.write(f"**Top30 positions (Top‑10 by HitCount):** {top30_positions}")
                if capture is not None:
                    st.write(f"**Top30 capture rate:** {capture:.1f}% of hits in the window")
                st.dataframe(pos_map, use_container_width=True, hide_index=True)

        st.divider()

        # Rare Engine panel
        st.markdown("## Rare Engine — AAAB + AABB")
        rare_tbl, rare_summary = evaluate_rare_engine(
            df_all=df_all,
            core=core,
            df_24h=df_24h,
            enable_r1=r1, enable_r2=r2, enable_r3=r3, enable_r4=r4,
            window_days_recent=cfg.window_days
        )

        c1, c2 = st.columns(2)
        with c1:
            st.caption("Trigger rule: at least **3** enabled checks must be TRUE (per stream).")
            if "error" in rare_summary:
                st.error(rare_summary["error"])
            else:
                st.write(f"R1 threshold (top‑20% baseline): **{rare_summary['thr_r1']:.4f} hits/week**")
                st.write(f"R2 threshold (top‑20% recent): **{rare_summary['thr_r2']:.4f} hits/week**")
                st.write(f"R3 global (24h ≥3 hits across ≥3 streams): **{rare_summary['r3_global']}**")
                st.write(f"R4 Top‑10 cluster positions (24h): **{rare_summary['top10_cluster_positions']}**")
                st.write(f"24h core hits: **{rare_summary['n_24h_core_hits']}** across **{rare_summary['n_24h_core_streams']}** streams")

        with c2:
            # Quick readout: which streams fire?
            if not rare_tbl.empty:
                trig_streams = rare_tbl.loc[rare_tbl["RareEngine_TRIG"], "Stream"].tolist()
                st.write("**Streams where Rare Engine fires:**")
                st.write("\n".join([f"- {s}" for s in trig_streams]) if trig_streams else "_None_")

                st.write("**When it fires, add these boxes:**")
                members = members_from_core(core, "AAAB") + members_from_core(core, "AABB")
                boxes = sorted(set(box_key(m) for m in members))
                st.write(", ".join(boxes))
            else:
                st.info("No rare-engine table yet.")

        if not rare_tbl.empty:
            cols = ["Stream","RankPos_full","HitsPerWeek_full","HitsPerWeek","DaysSinceLastHit",
                    "R1_top20_baseline","R2_top20_recent","R3_24h_has_3plus_across_3streams","R4_24h_cluster_top10pos",
                    "ChecksTrue","RareEngine_TRIG"]
            view = rare_tbl[cols].copy()
            view = view.rename(columns={
                "RankPos_full":"RankPos (baseline)",
                "HitsPerWeek_full":"Baseline hits/week",
                "HitsPerWeek":"Recent hits/week",
                "DaysSinceLastHit":"Days since last rare hit",
                "R1_top20_baseline":"R1",
                "R2_top20_recent":"R2",
                "R3_24h_has_3plus_across_3streams":"R3 (24h ≥3 hits/≥3 streams)",
                "R4_24h_cluster_top10pos":"R4",
                "ChecksTrue":"# checks TRUE",
                "RareEngine_TRIG":"RARE ENGINE",
            })
            st.dataframe(view, use_container_width=True, hide_index=True)

        st.divider()

        # Ultra-rare engine panel
        st.markdown("## Ultra‑Rare — Quads (AAAA)")
        ultra_tbl, ultra_summary = evaluate_ultra_rare_engine(
            df_all=df_all,
            core=core,
            df_24h=df_24h,
            enable_q1=q1, enable_q2=q2, enable_q3=q3, enable_q4=q4
        )

        u1, u2 = st.columns(2)
        with u1:
            st.caption("Trigger rule: at least **2** enabled checks must be TRUE (per stream).")
            if "error" in ultra_summary:
                st.error(ultra_summary["error"])
            else:
                st.write(f"Q1 threshold (top‑10% baseline): **{ultra_summary['thr_q1']:.4f} hits/week**")
                st.write(f"Q2 threshold (P90 due): **{ultra_summary['thr_q2']:.0f} days**")
                st.write(f"Q3 24h quad exists (core digits): **{ultra_summary['q3_global']}**")
                st.write(f"Q4 Top‑5 cluster positions (24h): **{ultra_summary['top5_cluster_positions']}**")
                st.write(f"24h core quad hits: **{ultra_summary['n_24h_core_quad_hits']}**")

        with u2:
            if not ultra_tbl.empty:
                trig_streams = ultra_tbl.loc[ultra_tbl["UltraRare_TRIG"], "Stream"].tolist()
                st.write("**Streams where Ultra‑Rare fires:**")
                st.write("\n".join([f"- {s}" for s in trig_streams]) if trig_streams else "_None_")
                st.write("**When it fires, add these quad boxes:**")
                q_members = members_from_core(core, "AAAA")
                st.write(", ".join(sorted(set(box_key(m) for m in q_members))))
            else:
                st.info("No ultra-rare table yet.")

        if not ultra_tbl.empty:
            cols = ["Stream","RankPos_full","HitsPerWeek_full","DaysSinceLastHit",
                    "Q1_top10_baseline","Q2_due_p90","Q3_24h_quad_exists","Q4_24h_cluster_top5pos",
                    "ChecksTrue","UltraRare_TRIG"]
            view = ultra_tbl[cols].copy()
            view = view.rename(columns={
                "RankPos_full":"RankPos (baseline)",
                "HitsPerWeek_full":"Baseline hits/week",
                "DaysSinceLastHit":"Days since last quad",
                "ChecksTrue":"# checks TRUE",
                "UltraRare_TRIG":"ULTRA‑RARE",
            })
            st.dataframe(view, use_container_width=True, hide_index=True)

        st.caption("Tip: Quads are extremely sparse. Use Ultra‑Rare as a *bonus watch*—not a daily expectation.")
