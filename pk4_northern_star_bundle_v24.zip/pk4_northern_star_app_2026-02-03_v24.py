
# pk4_northern_star_app_2026-02-03_v21.py
# Streamlit app: Pick 4 "Northern Star" core stream ranking + Rare/Ultra-Rare engines (AAAB+AABB, AAAA)
# Notes:
# - Designed to work with LotteryPost-style exports (tab .txt or .csv) that include Date, State, Game, Results.
# - Ignores Wild Ball / Fireball / multipliers by extracting the first 4 digits like "1-2-3-4".
# - Excludes Maryland by default (toggle in sidebar).

from __future__ import annotations

import re

def _safe_int(x):
    """Convert x to int if possible; returns None if not."""
    if x is None:
        return None
    if isinstance(x, int):
        return int(x)
    try:
        import numpy as _np
        if isinstance(x, (_np.integer,)):
            return int(x)
    except Exception:
        pass
    if isinstance(x, str):
        m = re.search(r"\d+", x)
        if not m:
            return None
        try:
            return int(m.group(0))
        except Exception:
            return None
    try:
        return int(x)
    except Exception:
        return None

import math
import itertools
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Tuple, Optional, Iterable

import numpy as np
import pandas as pd
import streamlit as st
import hashlib
import datetime
import json
from functools import lru_cache




# -------------------------
# Parsing + helpers
# -------------------------

# -------------------------
# Disk baseline cache (optional, keeps runs fast)
# -------------------------
from pathlib import Path as _Path

DISK_CACHE_DIR = _Path("pk4_baseline_cache")
DISK_CACHE_DIR.mkdir(exist_ok=True)

# -------------------------
# Rolling baseline store (optional)
# - Lets the app "self-maintain" a rolling ~3-year history by appending from the 24h file
# - Purges rows older than ~3 years from the newest date in the store
# - Stored on disk as parquet (preferred) or CSV (fallback), plus a small JSON meta file
# -------------------------
BASELINE_STORE_DIR = _Path("pk4_baseline_store")
BASELINE_STORE_DIR.mkdir(exist_ok=True)
BASELINE_STORE_BASE = BASELINE_STORE_DIR / "pk4_allstates_rolling_3y"

def _coerce_store_df(df: pd.DataFrame) -> pd.DataFrame:
    if df is None or df.empty:
        return pd.DataFrame()
    df = df.copy()
    # Ensure Date is datetime
    if "Date" in df.columns:
        df["Date"] = pd.to_datetime(df["Date"], errors="coerce")
        df = df[df["Date"].notna()].copy()
    # Ensure required columns exist (best-effort)
    for c in ["State","Game","Results","Pick4","Structure","Box","Stream"]:
        if c not in df.columns:
            df[c] = None
    return df

def load_baseline_store() -> pd.DataFrame:
    df = _safe_read_table(BASELINE_STORE_BASE)
    if df is None:
        return pd.DataFrame()
    df = _coerce_store_df(df)
    # Recompute derived fields if store was CSV without them
    if not df.empty:
        if "Pick4" not in df.columns or df["Pick4"].isna().all():
            df["Pick4"] = df.get("Results", pd.Series([None]*len(df))).map(extract_pick4_digits)
        if "Structure" not in df.columns or df["Structure"].isna().all():
            df["Structure"] = df["Pick4"].map(structure_of_4)
        if "Box" not in df.columns or df["Box"].isna().all():
            df["Box"] = df["Pick4"].map(box_key)
        if "Stream" not in df.columns or df["Stream"].isna().all():
            df["Stream"] = df["State"].astype(str).str.strip() + " | " + df["Game"].astype(str).str.strip()
        df = df[df["Pick4"].notna()].copy()
    return df

def write_baseline_store(df: pd.DataFrame, note: str = "") -> Tuple[bool, str]:
    df = _coerce_store_df(df)
    ok, path_written = _safe_write_table(df, BASELINE_STORE_BASE)
    meta = _read_meta(BASELINE_STORE_BASE)
    meta.update({
        "updated_at": datetime.datetime.now().isoformat(timespec="seconds"),
        "note": note,
        "rows": int(df.shape[0]) if df is not None else 0,
        "max_date": str(df["Date"].max()) if df is not None and not df.empty else "",
    })
    _write_meta(BASELINE_STORE_BASE, meta)
    return ok, path_written

def purge_to_rolling_3y(df: pd.DataFrame, years: int = 3) -> pd.DataFrame:
    df = _coerce_store_df(df)
    if df.empty:
        return df
    max_date = df["Date"].max()
    # 3-year rolling window; add a small buffer for leap years
    cutoff = pd.Timestamp(max_date) - pd.Timedelta(days=(365*years + 7))
    df2 = df[df["Date"] >= cutoff].copy()
    return df2

def append_from_24h(df_store: pd.DataFrame, df_24h: pd.DataFrame) -> Tuple[pd.DataFrame, int]:
    df_store = _coerce_store_df(df_store)
    df_24h = _coerce_store_df(df_24h)
    if df_24h.empty:
        return df_store, 0
    # Only keep rows with the needed fields
    df_24h = df_24h[["Date","State","Game","Results","Pick4","Structure","Box","Stream"]].copy()
    df_store = df_store[["Date","State","Game","Results","Pick4","Structure","Box","Stream"]].copy() if not df_store.empty else df_store

    # Dedup key: Date + State + Game (unique stream-day draw)
    def _key(df):
        return (
            df["Date"].dt.strftime("%Y-%m-%d").astype(str)
            + "|" + df["State"].astype(str).str.strip().str.lower()
            + "|" + df["Game"].astype(str).str.strip().str.lower()
        )
    if df_store.empty:
        out = df_24h.copy()
        return out, int(out.shape[0])

    store_keys = set(_key(df_store).tolist())
    df_24h["_k"] = _key(df_24h)
    new_rows = df_24h[~df_24h["_k"].isin(store_keys)].drop(columns=["_k"]).copy()
    if new_rows.empty:
        return df_store, 0
    out = pd.concat([df_store, new_rows], ignore_index=True)
    # Final dedup safety
    out["_k"] = _key(out)
    out = out.drop_duplicates(subset=["_k"]).drop(columns=["_k"]).copy()
    return out, int(new_rows.shape[0])

def _cache_key(max_date: pd.Timestamp, rows: int, streams: int, exclude_md: bool, window_days: int, cores: List[str]) -> str:
    # small, stable key so your cache survives restarts
    core_sig = "-".join(cores)
    base = f"{max_date.date()}|{rows}|{streams}|md={int(exclude_md)}|w={window_days}|{core_sig}"
    return hashlib.sha256(base.encode("utf-8")).hexdigest()[:16]

def _parquet_available() -> bool:
    try:
        import pyarrow  # noqa: F401
        return True
    except Exception:
        try:
            import fastparquet  # noqa: F401
            return True
        except Exception:
            return False

def _safe_write_table(df: pd.DataFrame, path: _Path) -> Tuple[bool, str]:
    """Write as parquet if possible, else as CSV (human readable)."""
    try:
        if _parquet_available():
            df.to_parquet(path.with_suffix(".parquet"), index=False)
            return True, str(path.with_suffix(".parquet"))
        df.to_csv(path.with_suffix(".csv"), index=False)
        return True, str(path.with_suffix(".csv"))
    except Exception as e:
        return False, f"{type(e).__name__}: {e}"

def _safe_read_table(path: _Path) -> Optional[pd.DataFrame]:
    p_parq = path.with_suffix(".parquet")
    p_csv = path.with_suffix(".csv")
    try:
        if p_parq.exists():
            return pd.read_parquet(p_parq)
        if p_csv.exists():
            return pd.read_csv(p_csv)
    except Exception:
        return None
    return None

def _read_meta(path: _Path) -> Dict[str, Any]:
    p = path.with_suffix(".json")
    if not p.exists():
        return {}
    try:
        return json.loads(p.read_text())
    except Exception:
        return {}

def _write_meta(path: _Path, meta: Dict[str, Any]) -> None:
    p = path.with_suffix(".json")
    p.write_text(json.dumps(meta, indent=2, default=str))

FOUR_DIGITS_RE = re.compile(r"(\d)\s*-\s*(\d)\s*-\s*(\d)\s*-\s*(\d)")


def _bytes_of_upload(uploaded) -> bytes:
    if uploaded is None:
        return b""
    try:
        return uploaded.getvalue()
    except Exception:
        try:
            return uploaded.read()
        except Exception:
            return b""

def file_fingerprint(uploaded) -> str:
    """Stable fingerprint for an uploaded file (used to auto-recompute when data changes)."""
    data = _bytes_of_upload(uploaded)
    if not data:
        return ""
    return hashlib.sha1(data).hexdigest()

def most_recent_date(df: pd.DataFrame) -> Optional[pd.Timestamp]:
    if df is None or df.empty or "Date" not in df.columns:
        return None
    try:
        return pd.to_datetime(df["Date"]).max()
    except Exception:
        return None
def extract_pick4_digits(results: str) -> Optional[str]:
    """Return 4-digit string from LotteryPost 'Results' cell, else None."""
    if results is None or (isinstance(results, float) and np.isnan(results)):
        return None
    m = FOUR_DIGITS_RE.search(str(results))
    if not m:
        # Sometimes results can be plain "1234"
        m2 = re.search(r"\b(\d{4})\b", str(results))
        if m2:
            return m2.group(1)
        return None
    return "".join(m.groups())

def box_key(s: str) -> str:
    return "".join(sorted(s))


from itertools import permutations

@lru_cache(maxsize=10000)
def unique_straights_for_box(box4: str) -> tuple[str, ...]:
    """Return unique 4-digit straight permutations for a 4-digit string (digits may repeat).

    Cached because the same box patterns repeat across streams/days.
    """
    box4 = extract_4digit(box4)
    if not box4:
        return tuple()
    return tuple(sorted({"".join(p) for p in permutations(box4, 4)}))

def _value_counts_result(df: pd.DataFrame) -> pd.Series:
    """Safe value_counts for Result column."""
    if df is None or df.empty:
        return pd.Series(dtype=int)
    if "Result" not in df.columns:
        return pd.Series(dtype=int)
    return df["Result"].astype(str).value_counts()

def _get_stream_result_counts(df_all: pd.DataFrame, stream: str) -> pd.Series:
    """Value counts of Result within a single stream."""
    if df_all is None or df_all.empty:
        return pd.Series(dtype=int)
    if "Stream" not in df_all.columns:
        return pd.Series(dtype=int)
    sub = df_all[df_all["Stream"].astype(str) == str(stream)]
    return _value_counts_result(sub)


def structure_of_4(d4: str) -> str:
    """Return AABC / AAAB / AABB / AAAA / ABCD based on counts."""
    from collections import Counter
    c = Counter(d4)
    counts = sorted(c.values(), reverse=True)
    if counts == [4]:
        return "AAAA"
    if counts == [3,1]:
        return "AAAB"
    if counts == [2,2]:
        return "AABB"
    if counts == [2,1,1]:
        return "AABC"
    return "ABCD"

def canonical_core_key(core: str) -> str:
    core = re.sub(r"\D", "", str(core))
    if len(core) == 3:
        return "".join(sorted(core))
    raise ValueError("Core must be 3 digits like 389")

def members_from_core(core_key: str, structure: str) -> List[str]:
    """Return box members (4-digit strings) for a 3-digit core, for a given structure."""
    core_key = canonical_core_key(core_key)
    a, b, c = list(core_key)
    if structure == "AABC":
        # Doubles for a 3-digit core: repeat one digit, include the other two once
        return [box_key(x) for x in [a+a+b+c, b+b+a+c, c+c+a+b]]
    if structure == "AAAB":
        # Triples: one digit x3 + one other digit x1 => 6 members
        return [box_key(x) for x in [a+a+a+b, a+a+a+c, b+b+b+a, b+b+b+c, c+c+c+a, c+c+c+b]]
    if structure == "AABB":
        # Double-doubles: choose two digits x2 => 3 members
        return [box_key(x) for x in [a+a+b+b, a+a+c+c, b+b+c+c]]
    if structure == "AAAA":
        return [box_key(x) for x in [a*4, b*4, c*4]]
    raise ValueError("Unsupported structure for core members: " + structure)

def try_read_tablelike(uploaded) -> pd.DataFrame:
    """
    Accept .csv or LotteryPost tab .txt.
    Expected columns (any case): Date, State, Game, Results (or Result/Winning Numbers).
    """
    if uploaded is None:
        return pd.DataFrame()

    name = getattr(uploaded, "name", "") or ""
    # try csv first
    try:
        df = pd.read_csv(uploaded)
        if df.shape[1] == 1:
            raise ValueError("Looks like 1-column; try tab.")
    except Exception:
        uploaded.seek(0)
        df = pd.read_csv(uploaded, sep="\t", header=None)
        # try to name columns if 4+ cols
        if df.shape[1] >= 4:
            df = df.iloc[:, :4]
            df.columns = ["Date", "State", "Game", "Results"]
        else:
            # fallback
            df.columns = [f"col_{i}" for i in range(df.shape[1])]

    # normalize column names
    colmap = {c.lower().strip(): c for c in df.columns}
    def pick(*cands):
        for c in cands:
            if c in colmap:
                return colmap[c]
        return None

    date_col = pick("date")
    state_col = pick("state")
    game_col = pick("game")
    results_col = pick("results", "result", "winning numbers", "winning_numbers", "winningnumbers")

    if date_col is None or state_col is None or game_col is None or results_col is None:
        # best-effort: if there are exactly 4 columns, assume those
        if df.shape[1] >= 4:
            df = df.iloc[:, :4].copy()
            df.columns = ["Date", "State", "Game", "Results"]
        else:
            raise ValueError("Could not detect Date/State/Game/Results columns.")
    else:
        df = df.rename(columns={
            date_col: "Date",
            state_col: "State",
            game_col: "Game",
            results_col: "Results",
        })

    # parse date
    df["Date"] = pd.to_datetime(df["Date"], errors="coerce")
    df = df[df["Date"].notna()].copy()

    # parse results
    df["Pick4"] = df["Results"].map(extract_pick4_digits)
    df = df[df["Pick4"].notna()].copy()
    # compatibility aliases used in other modules
    df["Result"] = df["Pick4"]

    df["Structure"] = df["Pick4"].map(structure_of_4)
    df["Box"] = df["Pick4"].map(box_key)
    df["BoxKey4"] = df["Box"]
    df["Stream"] = df["State"].astype(str).str.strip() + " | " + df["Game"].astype(str).str.strip()
    return df



def try_read_picklist(uploaded) -> pd.DataFrame:
    """
    Accept a simple list of Pick4 numbers (previous-day file) in .txt or .csv form.
    Extracts 4-digit sequences anywhere in the file.
    Returns a dataframe with: Result, Pick4, Box, BoxKey4, Structure.
    """
    if uploaded is None:
        return pd.DataFrame()

    try:
        raw = uploaded.read()
    except Exception:
        raw = None

    # Reset pointer for possible re-reads by caller
    try:
        uploaded.seek(0)
    except Exception:
        pass

    if raw is None:
        return pd.DataFrame()

    if isinstance(raw, bytes):
        try:
            s = raw.decode("utf-8", errors="ignore")
        except Exception:
            s = str(raw)
    else:
        s = str(raw)

    # Common case: one number per line, but we accept any separators
    nums = re.findall(r"(?<!\d)(\d{4})(?!\d)", s)
    if not nums:
        # try to read as a one-column csv
        try:
            uploaded.seek(0)
        except Exception:
            pass
        try:
            df1 = pd.read_csv(uploaded, header=None)
            flat = []
            for v in df1.iloc[:, 0].astype(str).tolist():
                flat += re.findall(r"(?<!\d)(\d{4})(?!\d)", v)
            nums = flat
        except Exception:
            nums = []

    nums = [str(n).zfill(4) for n in nums if n is not None]
    # de-dupe while preserving order
    seen = set()
    out = []
    for n in nums:
        if n not in seen:
            seen.add(n)
            out.append(n)

    df = pd.DataFrame({"Result": out})
    if df.empty:
        return df
    df["Pick4"] = df["Result"]
    df["Structure"] = df["Pick4"].map(structure_of_4)
    df["Box"] = df["Pick4"].map(box_key)
    df["BoxKey4"] = df["Box"]
    return df


# -------------------------
# Stats + ranking
# -------------------------

@dataclass
class RankConfig:
    # History window used for rank stats (default 180, switchable to 365 in UI)
    window_days: int = 180

    # Bucket method:
    # - Top 'top_base' by BaseScore (HitsPerWeek)
    # - From base ranks due_from_rank..due_to_rank, take Top 'top_due' by DueIndex (DaysSinceLastHit)
    top_base: int = 12
    due_from_rank: int = 13
    due_to_rank: int = 60
    top_due: int = 8

    # Display / scoring knobs (kept as soft signals)
    max_master_rows: int = 120
    max_final_rows: int = 300
    include_24h_signals: bool = True
    pos_strength_weight: float = 0.25
    seed_core_key: str = "core"  # reserved for future compatibility

    # Back-compat aliases (older UI keys)
    @property
    def top12(self) -> int:
        return int(self.top_base)

    @property
    def due_ranks(self):
        return (int(self.due_from_rank), int(self.due_to_rank))


def within_last_days(df: pd.DataFrame, days: int) -> pd.DataFrame:
    if df.empty:
        return df
    max_date = df["Date"].max()
    cutoff = max_date - pd.Timedelta(days=days)
    return df[df["Date"] >= cutoff].copy()

def compute_core_hits(df: pd.DataFrame, core: str, structures: Iterable[str]) -> pd.DataFrame:
    """
    Return df subset containing only rows that are hits for the core, for the chosen structures.
    We match by Box membership, so order doesn't matter.
    """
    core = canonical_core_key(core)
    boxes = set()
    for s in structures:
        for mem in members_from_core(core, s):
            boxes.add(box_key(mem))
    return df[df["Box"].isin(boxes)].copy()

def stream_summary(df_all: pd.DataFrame, df_hits: pd.DataFrame, window_days: int) -> pd.DataFrame:
    """
    For each stream, compute:
    - draws_window, hits_window, hits_per_week_window
    - days_since_last_hit_window (based on df_hits within full history)
    """
    if df_all.empty:
        return pd.DataFrame(columns=[
            "Stream","DrawsWindow","HitsWindow","HitsPerWeek","LastHitDate","DaysSinceLastHit"
        ])

    dfw = within_last_days(df_all, window_days)
    max_date = df_all["Date"].max()

    draws = dfw.groupby("Stream").size().rename("DrawsWindow")
    hitsw = within_last_days(df_hits, window_days).groupby("Stream").size().rename("HitsWindow")

    # last hit date from full history (not just window) for "due"
    last_hit = df_hits.groupby("Stream")["Date"].max().rename("LastHitDate")

    out = pd.concat([draws, hitsw, last_hit], axis=1).fillna({"HitsWindow":0})
    out["HitsWindow"] = out["HitsWindow"].astype(int)
    out["DrawsWindow"] = out["DrawsWindow"].astype(int)

    weeks = max(window_days / 7.0, 1e-9)
    out["HitsPerWeek"] = out["HitsWindow"] / weeks

    out["DaysSinceLastHit"] = (max_date - out["LastHitDate"]).dt.days
    out.loc[out["LastHitDate"].isna(), "DaysSinceLastHit"] = np.nan

    out = out.reset_index().sort_values(["HitsPerWeek","HitsWindow"], ascending=False)
    out["RankPos"] = np.arange(1, len(out)+1)
    return out

def position_percentile_map(stream_stats: pd.DataFrame) -> pd.DataFrame:
    """
    Create a rank-position map (RankPos -> HitCount) + percentiles and cumulative share.
    This is what you wanted for Northern Star: positions are individual, not ranges.
    """
    if stream_stats.empty:
        return pd.DataFrame(columns=["RankPos","HitCount","HitShare","CumHitShare","HitCountPctile"])

    total_hits = stream_stats["HitsWindow"].sum()
    pos = stream_stats[["RankPos","HitsWindow"]].rename(columns={"HitsWindow":"HitCount"}).copy()
    pos["HitShare"] = (pos["HitCount"] / total_hits) if total_hits > 0 else 0.0
    pos = pos.sort_values("RankPos")
    pos["CumHitShare"] = pos["HitShare"].cumsum()

    # percentile by HitCount (higher hitcount -> higher percentile)
    pos["HitCountPctile"] = pos["HitCount"].rank(pct=True) * 100.0
    pos["HitCountPctile"] = pos["HitCountPctile"].round(1)
    pos["HitShare"] = (pos["HitShare"] * 100.0).round(2)
    pos["CumHitShare"] = (pos["CumHitShare"] * 100.0).round(2)

    return pos


def get_position_percentiles_cached(core: str, window_days: int, stream_stats: pd.DataFrame) -> pd.DataFrame:
    """Cache position percentile maps per core/window so UI tweaks don't constantly recompute.
    Cache is automatically cleared when input data changes or when the user clicks 'Recompute percentile maps now'.
    """
    cache: Dict[str, pd.DataFrame] = st.session_state.get("pos_map_cache", {})
    data_hash = st.session_state.get("data_hash_all", "")
    key = f"{core}|{window_days}|{data_hash}"

    if key in cache:
        return cache[key]

    pos_map = position_percentile_map(stream_stats)
    cache[key] = pos_map
    st.session_state["pos_map_cache"] = cache

    if not st.session_state.get("recompute_token"):
        st.session_state["recompute_token"] = datetime.datetime.now().isoformat(timespec="seconds")

    return pos_map

def bucket_recommendations(stream_stats: pd.DataFrame, cfg: RankConfig) -> Dict[str, List[str]]:
    """
    Bucket method:
    - Take Top cfg.top_base by BaseScore (HitsPerWeek).
    - From ranks cfg.due_from_rank..cfg.due_to_rank, take Top cfg.top_due by DueIndex (DaysSinceLastHit).
    """
    if stream_stats.empty:
        return {"base_top":[], "due_top":[], "combined":[]}

    s = stream_stats.copy()

    # Base top
    base = s.nsmallest(cfg.top_base, "RankPos")["Stream"].tolist()

    # Due bucket from rank range
    due_pool = s[(s["RankPos"] >= cfg.due_from_rank) & (s["RankPos"] <= cfg.due_to_rank)].copy()
    # When last-hit is NaN (never hit), treat as very due
    due_pool["DueIndex"] = due_pool["DaysSinceLastHit"].fillna(due_pool["DaysSinceLastHit"].max() if due_pool["DaysSinceLastHit"].notna().any() else 0) + 0.01
    due = due_pool.sort_values("DueIndex", ascending=False).head(cfg.top_due)["Stream"].tolist()

    combined = []
    for x in base + due:
        if x not in combined:
            combined.append(x)

    return {"base_top": base, "due_top": due, "combined": combined}

def top_dense_positions(pos_map: pd.DataFrame, top_n: int = 10) -> List[int]:
    """Return the top-N rank positions (1..76) that collectively hold the most winners."""
    if pos_map is None or pos_map.empty:
        return []
    tmp = pos_map.copy()
    # Defensive: sometimes RankPos can come back as strings; coerce to numeric
    tmp["RankPos_num"] = pd.to_numeric(tmp["RankPos"], errors="coerce")
    tmp = tmp.dropna(subset=["RankPos_num"])
    if tmp.empty:
        return []
    tmp["RankPos_num"] = tmp["RankPos_num"].astype(int)
    counts = tmp.groupby("RankPos_num")["HitCount"].sum().sort_values(ascending=False).head(int(top_n))
    return [int(x) for x in counts.index.tolist()]

def engine_cluster_positions(
    top_positions_or_df,
    base_stats: pd.DataFrame | None = None,
    top_n: int = 10,
    cluster_size: int = 5,
    label: str | None = None,
) -> List[int]:
    """Return a small set of the densest baseline RankPos values (for .isin()).

    Backward compatible:
      - If you pass a list/iterable of positions, we clean/dedupe and return a cluster.
      - If you pass (df_24h_core_hits, base_stats), we compute hit-density by baseline RankPos first.

    Notes:
      - We return a **list of ints** (never a string) so callers can safely use pandas .isin().
      - When inputs are missing/empty, we return [].
    """
    # Determine label (kept for backward compatibility even though we now return a list)
    if label is None:
        label = f"Top{int(top_n)}"

    # Case 1: caller passed a list/iterable of positions
    if isinstance(top_positions_or_df, (list, tuple, set)):
        top_positions = list(top_positions_or_df)
    else:
        # Case 2: caller passed df_24h_core_hits and base_stats
        df_24h_core_hits = top_positions_or_df
        if df_24h_core_hits is None or getattr(df_24h_core_hits, "empty", True) or base_stats is None or base_stats.empty:
            return []

        # Expect Stream column in both
        if "Stream" not in df_24h_core_hits.columns or "Stream" not in base_stats.columns:
            return []

        # Determine rank position column
        if "RankPos" in base_stats.columns:
            rank_col = "RankPos"
        elif "RankPos_full" in base_stats.columns:
            rank_col = "RankPos_full"
        else:
            return []

        # Count hits by Stream in the 24h map
        hit_counts = df_24h_core_hits.groupby("Stream").size().reset_index(name="HitCount")

        # Map streams to their baseline rank position
        rank_map = base_stats[["Stream", rank_col]].copy()
        rank_map["RankPos"] = pd.to_numeric(rank_map[rank_col], errors="coerce")
        rank_map = rank_map.dropna(subset=["RankPos"])
        if rank_map.empty:
            return []
        rank_map["RankPos"] = rank_map["RankPos"].astype(int)

        pos_map = hit_counts.merge(rank_map[["Stream", "RankPos"]], on="Stream", how="inner")
        if pos_map.empty:
            return []

        # Get densest RankPos values (top_n)
        top_positions = top_dense_positions(pos_map, top_n=int(top_n))

    if not top_positions:
        return []

    cleaned: List[int] = []
    for x in top_positions:
        xi = _safe_int(x)
        if xi is None:
            continue
        cleaned.append(int(xi))

    if not cleaned:
        return []

    cleaned = sorted(set(cleaned))
    cluster = cleaned[: max(1, int(cluster_size))]
    return cluster
def evaluate_rare_engine(
    df_all: pd.DataFrame,
    core: str,
    df_24h: pd.DataFrame,
    enable_r1: bool,
    enable_r2: bool,
    enable_r3: bool,
    enable_r4: bool,
    window_days_recent: int = 180,
) -> Tuple[pd.DataFrame, Dict[str, object]]:
    """
    Rare Engine checks (AAAB + AABB together):
      R1: stream is in top 20% for combined AAAB+AABB baseline rate (full history).
      R2: stream is in top 20% for combined AAAB+AABB rate in last 180 days.
      R3: the last 24h map contains ≥3 AAAB/AABB hits across ≥3 distinct streams (global condition).
      R4: last 24h AAAB/AABB hits cluster into Top-10 RankPos, and stream RankPos is in that set.
    Trigger: at least 3 of enabled checks True.

    Returns:
      - per-stream table with booleans and trigger
      - summary dict with thresholds and cluster sets
    """
    if df_all.empty:
        return pd.DataFrame(), {"error":"No history loaded."}

    core = canonical_core_key(core)
    df_hits_all = compute_core_hits(df_all, core, structures=["AAAB","AABB"])

    # Baseline stream stats
    base_stats = stream_summary(df_all, df_hits_all, window_days=min(365*5, int((df_all["Date"].max()-df_all["Date"].min()).days) or 365))
    # But we want baseline based on full history span; use hits per week in that span:
    span_days = max(int((df_all["Date"].max()-df_all["Date"].min()).days), 1)
    base_stats["HitsPerWeek_full"] = base_stats["HitsWindow"] / (span_days/7.0)
    base_stats = base_stats.sort_values(["HitsPerWeek_full","HitsWindow"], ascending=False).reset_index(drop=True)
    base_stats["RankPos_full"] = np.arange(1, len(base_stats)+1)

    # Recent stats (180d)
    recent_stats = stream_summary(df_all, df_hits_all, window_days=window_days_recent)

    # Thresholds
    def pct_threshold(series: pd.Series, pct: float) -> float:
        vals = series.dropna().values
        if len(vals)==0:
            return float("nan")
        return float(np.quantile(vals, pct))

    # R1 top 20% based on HitsPerWeek_full
    thr_r1 = pct_threshold(base_stats["HitsPerWeek_full"], 0.80)

    # R2 top 20% based on recent HitsPerWeek
    thr_r2 = pct_threshold(recent_stats["HitsPerWeek"], 0.80)

    # R3 global condition from 24h file: ≥3 hits across ≥3 distinct streams
    df_24h_core_hits = pd.DataFrame()
    top10_cluster = []
    r3_global = False
    if df_24h is not None and not df_24h.empty:
        df_24h_core_hits = compute_core_hits(df_24h, core, structures=["AAAB","AABB"])
        n_hits_24h = int(len(df_24h_core_hits))
        n_streams_24h = int(df_24h_core_hits["Stream"].nunique()) if n_hits_24h else 0
        r3_global = (n_hits_24h >= 3) and (n_streams_24h >= 3)
        # R4 cluster based on 24h file (Top-10 RankPos positions by 24h frequency)
        top10_cluster = engine_cluster_positions(
            df_24h_core_hits,
            base_stats.rename(columns={"RankPos_full":"RankPos"}).assign(RankPos=base_stats["RankPos_full"]),
            top_n=10,
        )

    # Merge per stream
    out = pd.DataFrame({"Stream": base_stats["Stream"]})
    out = out.merge(base_stats[["Stream","HitsPerWeek_full","RankPos_full"]], on="Stream", how="left")
    out = out.merge(recent_stats[["Stream","HitsPerWeek","DaysSinceLastHit","RankPos"]].rename(columns={"RankPos":"RankPos_recent"}), on="Stream", how="left")

    out["R1_top20_baseline"] = out["HitsPerWeek_full"] >= thr_r1 if enable_r1 else False
    out["R2_top20_recent"] = out["HitsPerWeek"] >= thr_r2 if enable_r2 else False
    out["R3_24h_has_3plus_across_3streams"] = r3_global if enable_r3 else False
    out["R4_24h_cluster_top10pos"] = out["RankPos_full"].isin(top10_cluster) if enable_r4 else False

    enabled_cols = [c for c, en in [
        ("R1_top20_baseline", enable_r1),
        ("R2_top20_recent", enable_r2),
        ("R3_24h_has_3plus_across_3streams", enable_r3),
        ("R4_24h_cluster_top10pos", enable_r4),
    ] if en]

    out["ChecksTrue"] = out[enabled_cols].sum(axis=1) if enabled_cols else 0
    out["RareEngine_TRIG"] = out["ChecksTrue"] >= 3 if enabled_cols else False

    out = out.sort_values(["RareEngine_TRIG","ChecksTrue","HitsPerWeek_full"], ascending=[False, False, False]).reset_index(drop=True)

    summary = {
        "thr_r1": thr_r1,
        "thr_r2": thr_r2,
        "r3_global": r3_global,
        "top10_cluster_positions": top10_cluster,
        "n_24h_core_hits": int(len(df_24h_core_hits)) if df_24h is not None else 0,
        "n_24h_core_streams": int(df_24h_core_hits["Stream"].nunique()) if df_24h is not None and not df_24h_core_hits.empty else 0,
        "span_days_full": span_days,
        "enabled_checks": enabled_cols,
    }
    return out, summary

def evaluate_ultra_rare_engine(
    df_all: pd.DataFrame,
    core: str,
    df_24h: pd.DataFrame,
    enable_q1: bool,
    enable_q2: bool,
    enable_q3: bool,
    enable_q4: bool,
) -> Tuple[pd.DataFrame, Dict[str, object]]:
    """
    Ultra-Rare Engine checks (AAAA quads for the core's digits):
      Q1: stream in top 10% for quad baseline rate (full history)
      Q2: days since last quad >= 90th percentile across streams
      Q3: last 24h has at least 1 quad anywhere (for any digit in core)
      Q4: 24h quad hits (for core) cluster into Top-5 RankPos; stream position is in that set
    Trigger: at least 2 of enabled checks True.
    """
    if df_all.empty:
        return pd.DataFrame(), {"error":"No history loaded."}

    core = canonical_core_key(core)
    df_hits_all = compute_core_hits(df_all, core, structures=["AAAA"])

    span_days = max(int((df_all["Date"].max()-df_all["Date"].min()).days), 1)
    base_stats = stream_summary(df_all, df_hits_all, window_days=min(365*5, span_days))
    base_stats["HitsPerWeek_full"] = base_stats["HitsWindow"] / (span_days/7.0)
    base_stats = base_stats.sort_values(["HitsPerWeek_full","HitsWindow"], ascending=False).reset_index(drop=True)
    base_stats["RankPos_full"] = np.arange(1, len(base_stats)+1)

    # thresholds
    def pct_threshold(series: pd.Series, pct: float) -> float:
        vals = series.dropna().values
        if len(vals)==0:
            return float("nan")
        return float(np.quantile(vals, pct))

    thr_q1 = pct_threshold(base_stats["HitsPerWeek_full"], 0.90)
    thr_q2 = pct_threshold(base_stats["DaysSinceLastHit"], 0.90)  # DaysSinceLastHit computed from last quad date

    # Q3 global 24h quad exists for any core digit
    q3_global = False
    df_24h_core_hits = pd.DataFrame()
    top5_cluster = []
    if df_24h is not None and not df_24h.empty:
        # any quad in 24h that uses one of core digits
        core_digits = set(core)
        df_24h_quads = df_24h[df_24h["Structure"]=="AAAA"].copy()
        df_24h_quads["quad_digit"] = df_24h_quads["Pick4"].str[0]
        q3_global = df_24h_quads["quad_digit"].isin(core_digits).any()
        df_24h_core_hits = compute_core_hits(df_24h, core, structures=["AAAA"])
        top5_cluster = engine_cluster_positions(df_24h_core_hits, base_stats.rename(columns={"RankPos_full":"RankPos"}).assign(RankPos=base_stats["RankPos_full"]), top_n=5)

    out = pd.DataFrame({"Stream": base_stats["Stream"]})
    out = out.merge(base_stats[["Stream","HitsPerWeek_full","DaysSinceLastHit","RankPos_full"]], on="Stream", how="left")

    out["Q1_top10_baseline"] = out["HitsPerWeek_full"] >= thr_q1 if enable_q1 else False
    out["Q2_due_p90"] = out["DaysSinceLastHit"] >= thr_q2 if enable_q2 else False
    out["Q3_24h_quad_exists"] = q3_global if enable_q3 else False
    out["Q4_24h_cluster_top5pos"] = out["RankPos_full"].isin(top5_cluster) if enable_q4 else False

    enabled_cols = [c for c, en in [
        ("Q1_top10_baseline", enable_q1),
        ("Q2_due_p90", enable_q2),
        ("Q3_24h_quad_exists", enable_q3),
        ("Q4_24h_cluster_top5pos", enable_q4),
    ] if en]

    out["ChecksTrue"] = out[enabled_cols].sum(axis=1) if enabled_cols else 0
    out["UltraRare_TRIG"] = out["ChecksTrue"] >= 2 if enabled_cols else False

    out = out.sort_values(["UltraRare_TRIG","ChecksTrue","HitsPerWeek_full"], ascending=[False, False, False]).reset_index(drop=True)

    summary = {
        "thr_q1": thr_q1,
        "thr_q2": thr_q2,
        "q3_global": q3_global,
        "top5_cluster_positions": top5_cluster,
        "n_24h_core_quad_hits": int(len(df_24h_core_hits)) if df_24h is not None else 0,
        "enabled_checks": enabled_cols,
        "span_days_full": span_days,
    }
    return out, summary


# -------------------------
# UI
# -------------------------

st.set_page_config(page_title="Pick 4 Northern Star", layout="wide")

st.title("Pick 4 — Northern Star + Rare Engine (AAAB+AABB) + Ultra‑Rare (AAAA)")

# Safe init for sidebar footer (values are filled after parsing uploads)
last_all = None
last_24 = None
df_all = None
df_24 = None


with st.sidebar:
    st.header("Data")
    master_file = st.file_uploader("All‑states history file (.csv or LotteryPost .txt)", type=["csv","txt"])
    map24_file = st.file_uploader("24h map file (optional, same format)", type=["csv","txt"])


    st.divider()
    st.subheader("Self-update rolling baseline (optional)")
    use_store = st.checkbox("Use local rolling ~3-year baseline store", value=False, help="Keeps a local rolling baseline by appending new rows from the 24h file and purging rows older than ~3 years. This improves speed and keeps your baseline fresh without you manually editing the all-states file.")
    st.session_state["use_store"] = use_store

    if use_store:
        store_df_preview = load_baseline_store()
        store_meta = _read_meta(BASELINE_STORE_BASE)
        store_rows = int(store_meta.get("rows", store_df_preview.shape[0] if store_df_preview is not None else 0) or 0)
        store_max = store_meta.get("max_date", "") or (str(store_df_preview["Date"].max()) if store_df_preview is not None and not store_df_preview.empty else "")
        st.caption(f"Store status: {store_rows:,} rows | newest date: {store_max if store_max else '—'}")

        colA, colB = st.columns(2)
        with colA:
            if st.button("Initialize/overwrite store from uploaded all-states file"):
                if master_file is None:
                    st.warning("Upload the all-states history file first.")
                else:
                    try:
                        master_file.seek(0)
                    except Exception:
                        pass
                    try:
                        df_init = try_read_tablelike(master_file)
                        df_init = purge_to_rolling_3y(df_init, years=3)
                        ok, wrote = write_baseline_store(df_init, note="Initialized from uploaded all-states file (rolling 3y).")
                        st.success(f"Baseline store saved: {wrote}")
                    except Exception as e:
                        st.error(f"Could not initialize store: {e}")
                    try:
                        master_file.seek(0)
                    except Exception:
                        pass
        with colB:
            if st.button("Append 24h file into store (and purge)"):
                if map24_file is None:
                    st.warning("Upload the 24h file first.")
                else:
                    try:
                        map24_file.seek(0)
                    except Exception:
                        pass
                    try:
                        df_new = try_read_tablelike(map24_file)
                        df_store = load_baseline_store()
                        merged, added = append_from_24h(df_store, df_new)
                        merged = purge_to_rolling_3y(merged, years=3)
                        ok, wrote = write_baseline_store(merged, note=f"Appended from 24h file (+{added} new rows), then purged to rolling 3y.")
                        st.success(f"Updated store: +{added} new rows. Saved: {wrote}")
                    except Exception as e:
                        st.error(f"Could not append 24h into store: {e}")
                    try:
                        map24_file.seek(0)
                    except Exception:
                        pass

        if st.button("Export store as CSV (human readable)"):
            df_store = load_baseline_store()
            if df_store.empty:
                st.warning("Store is empty.")
            else:
                # write CSV next to store base
                csv_path = BASELINE_STORE_BASE.with_suffix(".csv")
                df_store.to_csv(csv_path, index=False)
                st.success(f"Exported: {csv_path}")

    exclude_md = st.checkbox("Exclude Maryland streams", value=True)

    # Percentile tools (updateable)
    if "pos_map_cache" not in st.session_state:
        st.session_state["pos_map_cache"] = {}
    if "recompute_token" not in st.session_state:
        st.session_state["recompute_token"] = ""
    if st.button("Recompute percentile maps now"):
        st.session_state["pos_map_cache"] = {}
        st.session_state["recompute_token"] = datetime.datetime.now().isoformat(timespec="seconds")
    if st.session_state.get("recompute_token"):
        st.caption(f"Percentiles last recomputed: {st.session_state['recompute_token']}")
    st.divider()

    st.header("Core selection")
    # Pick a single core to view (dropdown), and optionally a larger set for cache building.
    CORE_OPTIONS = ['016', '017', '018', '019', '023', '024', '025', '027', '028', '029', '038', '046', '048', '056', '059', '067', '068', '078', '129', '135', '145', '146', '149', '167', '168', '169', '179', '236', '238', '239', '245', '246', '249', '257', '258', '278', '279', '345', '348', '357', '359', '378', '379', '389', '457', '459', '489', '567', '579', '589', '679', '689', '789']
    view_core = st.selectbox("View core (dropdown)", options=CORE_OPTIONS, index=CORE_OPTIONS.index("389") if "389" in CORE_OPTIONS else 0)
    cores_for_cache = st.multiselect("Cores to include for cache building / batch tools", options=CORE_OPTIONS, default=[view_core])
    show_tabs = st.checkbox("Show tabs for all selected cores (can be slower)", value=False)
    cores = sorted(list(dict.fromkeys((cores_for_cache if show_tabs else [view_core]))))

    st.divider()
    st.header("Northern Star window")
    window_days = st.radio("Window (days)", options=[180, 365], index=0, horizontal=True)
    cfg = RankConfig(window_days=window_days)

    st.caption("Bucket method: Top 12 BaseScore (Hits/week) + Top 8 DueIndex from ranks 13–60.")

    st.divider()
    st.header("Rare Engine trigger — AAAB + AABB")
    r1 = st.checkbox("R1: Top‑20% baseline AAAB+AABB", value=True)
    r2 = st.checkbox("R2: Top‑20% recent (last window)", value=True)
    r3 = st.checkbox("R3: 24h has ≥3 AAAB/AABB hits across ≥3 streams", value=True)
    r4 = st.checkbox("R4: 24h cluster ∈ Top‑10 positions", value=True)

    st.divider()
    st.header("Ultra‑Rare trigger — AAAA")
    q1 = st.checkbox("Q1: Top‑10% quad baseline", value=True)
    q2 = st.checkbox("Q2: Due pressure ≥ P90", value=True)
    q3 = st.checkbox("Q3: 24h quad exists (core digits)", value=True)
    q4 = st.checkbox("Q4: 24h cluster ∈ Top‑5 positions", value=True)

    st.divider()
    straights_opt = st.checkbox("Generate straights shortlist (optional last)", value=False)


# Load data
use_store = bool(st.session_state.get("use_store", False))

if use_store:
    # Prefer the on-disk rolling store if present
    df_all = load_baseline_store()
    # If the store is empty but the user uploaded a master file, auto-initialize (rolling 3y)
    if (df_all is None or df_all.empty) and master_file is not None:
        try:
            master_file.seek(0)
        except Exception:
            pass
        df_all = try_read_tablelike(master_file)
        df_all = purge_to_rolling_3y(df_all, years=3)
        try:
            write_baseline_store(df_all, note="Auto-initialized store from uploaded all-states file (rolling 3y).")
        except Exception:
            pass
        try:
            master_file.seek(0)
        except Exception:
            pass
else:
    df_all = try_read_tablelike(master_file) if master_file else pd.DataFrame()

prev_picklist = pd.DataFrame()
df_24h = pd.DataFrame()
if map24_file:
    try:
        df_24h = try_read_tablelike(map24_file)
    except Exception:
        # Many users upload a simple pick-list here (one 4-digit number per line).
        # Accept it without crashing; it will NOT be used for 24h engines or baseline self-update.
        try:
            map24_file.seek(0)
        except Exception:
            pass
        try:
            prev_picklist = try_read_picklist(map24_file)
            if not prev_picklist.empty:
                st.info(
                    "Optional 24h/previous-day file detected as a pick-list (not a LotteryPost history export). "
                    "It will be used only for annotation/downranking where applicable."
                )
        except Exception as e:
            st.warning(f"Could not parse optional 24h/previous-day file: {e}")


if exclude_md and not df_all.empty:
    df_all = df_all[df_all["State"].astype(str).str.strip().str.lower() != "maryland"].copy()
if exclude_md and not df_24h.empty:
    df_24h = df_24h[df_24h["State"].astype(str).str.strip().str.lower() != "maryland"].copy()

# Back-compat alias used by the Northern Lights block
df_24 = df_24h


# Auto-clear cached percentile maps when input data changes
if use_store:
    _m = _read_meta(BASELINE_STORE_BASE)
    all_hash = f"store|{_m.get('max_date','')}|{_m.get('rows','')}"
else:
    all_hash = file_fingerprint(master_file)
map_hash = file_fingerprint(map24_file)
if "data_hash_all" not in st.session_state:
    st.session_state["data_hash_all"] = ""
if "data_hash_24h" not in st.session_state:
    st.session_state["data_hash_24h"] = ""

if all_hash and all_hash != st.session_state["data_hash_all"]:
    st.session_state["pos_map_cache"] = {}
    st.session_state["data_hash_all"] = all_hash
    st.session_state["recompute_token"] = ""  # will refresh on next compute
if map_hash != st.session_state["data_hash_24h"]:
    st.session_state["pos_map_cache"] = {}
    st.session_state["data_hash_24h"] = map_hash
    st.session_state["recompute_token"] = ""

# Show data freshness (so the instructions never need updating)
last_all = most_recent_date(df_all)
last_24 = most_recent_date(df_24h)

today = datetime.date.today()
def _age_days(ts: Optional[pd.Timestamp]) -> Optional[int]:
    if ts is None or pd.isna(ts):
        return None
    try:
        d = pd.to_datetime(ts).date()
        return (today - d).days
    except Exception:
        return None

st.sidebar.markdown("### Data freshness")
if last_all is not None and not pd.isna(last_all):
    st.sidebar.caption(f"All‑states history most recent date: {pd.to_datetime(last_all).date()}  (age: {_age_days(last_all)} days)")
else:
    st.sidebar.caption("All‑states history most recent date: (not found)")

if last_24 is not None and not pd.isna(last_24):
    st.sidebar.caption(f"24h map most recent date: {pd.to_datetime(last_24).date()}  (age: {_age_days(last_24)} days)")
else:
    st.sidebar.caption("24h map most recent date: (not uploaded)")

st.sidebar.caption(f"Tip: if ages are >1–2 days, your files are probably behind.")

if master_file is None:
    st.info("Upload your all‑states history file to start.")
    st.stop()

if df_all.empty:
    st.error("Could not parse your history file. Make sure it contains Date, State, Game, Results.")
    st.stop()

# One place to show dataset info
colA, colB, colC = st.columns(3)
with colA:
    st.metric("Rows (draws)", f"{len(df_all):,}")
with colB:
    st.metric("Streams", f"{df_all['Stream'].nunique():,}")
with colC:
    min_d = df_all["Date"].min().date().isoformat()
    max_d = df_all["Date"].max().date().isoformat()
    st.caption(f"Date span: {min_d} → {max_d}")


st.divider()
# ----------------------------
# Baseline disk cache (optional)
# ----------------------------
def _baseline_paths(core: str, window_days: int):
    core = str(core).zfill(3)
    base = DISK_CACHE_DIR / f"baseline_{window_days}d_{core}"
    return {
        "stream": base.with_suffix(".stream.parquet"),
        "pos": base.with_suffix(".pos.parquet"),
        "meta": base.with_suffix(".meta.json"),
    }

def _load_baseline_from_disk(core: str, window_days: int, expected_last_date: str | None):
    p = _baseline_paths(core, window_days)
    meta = _read_meta(p["meta"])
    if not meta:
        return None, None, None
    if expected_last_date and meta.get("last_date") != expected_last_date:
        return None, None, meta
    stream_df = _safe_read_table(p["stream"])
    pos_df = _safe_read_table(p["pos"])
    if stream_df is None or pos_df is None:
        return None, None, meta
    return stream_df, pos_df, meta

def _save_baseline_to_disk(core: str, window_days: int, stream_df, pos_df, last_date: str | None):
    p = _baseline_paths(core, window_days)
    _safe_write_table(stream_df, p["stream"])
    _safe_write_table(pos_df, p["pos"])
    _write_meta(p["meta"], {
        "core": str(core).zfill(3),
        "window_days": int(window_days),
        "last_date": last_date,
        "built_at": _dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
    })

def get_stream_stats_cached(core: str, window_days: int, df_all, last_date: str | None):
    key = f"stream_stats::{window_days}::{str(core).zfill(3)}"
    if key in st.session_state:
        return st.session_state[key]
    # Try disk cache
    stream_df, pos_df, meta = _load_baseline_from_disk(core, window_days, expected_last_date=last_date)
    if stream_df is not None:
        st.session_state[key] = stream_df
        # also stash pos if present
        if pos_df is not None:
            st.session_state[f"pos_map::{window_days}::{str(core).zfill(3)}"] = pos_df
        return stream_df
    # Compute fresh
    hits = compute_core_hits(df_all, core, structures=("AABC",))
    stream_df = stream_summary(df_all, hits, window_days=window_days)
    st.session_state[key] = stream_df
    return stream_df


def compute_stream_stats(df_all: pd.DataFrame, core: str, window_days: int, exclude_md: bool = False) -> pd.DataFrame:
    """Back-compat wrapper used by the Northern Lights block."""
    # exclude_md is already applied upstream; kept only for compatibility
    last_date = most_recent_date(df_all)
    last_s = None
    if last_date is not None and not pd.isna(last_date):
        try:
            last_s = str(pd.to_datetime(last_date).date())
        except Exception:
            last_s = None
    return get_stream_stats_cached(core=str(core), window_days=int(window_days), df_all=df_all, last_date=last_s)


def build_northern_star_buckets(
    stats_df: pd.DataFrame,
    stream: str,
    top_n: int,
    due_ranks: Tuple[int, int],
    seed_core_key: str,
    include_24h: bool,
    df_24: Optional[pd.DataFrame],
    core: str,
) -> Dict[str, object]:
    """
    Back-compat bucket logic for the Northern Lights table:
    - Base bucket: Top N streams by HitsPerWeek
    - Due bucket: from base ranks [due_from..due_to], take Top cfg.top_due by DaysSinceLastHit
    Returns fields expected by the Northern Lights renderer.
    """
    if stats_df is None or stats_df.empty:
        return {}

    s = stats_df.copy()
    s = s.sort_values(["HitsPerWeek", "HitsWindow"], ascending=[False, False]).reset_index(drop=True)
    s["BaseRank"] = s.index + 1

    # Base top
    base_top_streams = set(s.head(int(top_n))["Stream"].astype(str).tolist())

    # Due candidates are chosen from the *base-ranked* band
    d1, d2 = int(due_ranks[0]), int(due_ranks[1])
    band = s[(s["BaseRank"] >= d1) & (s["BaseRank"] <= d2)].copy()
    if band.empty:
        due_top_streams = set()
    else:
        band = band.sort_values(["DaysSinceLastHit", "HitsPerWeek"], ascending=[False, False])
        due_top_streams = set(band.head(int(getattr(st.session_state.get("_cfg", RankConfig()), "top_due", 8)))["Stream"].astype(str).tolist())

    in_base = str(stream) in base_top_streams
    in_due = str(stream) in due_top_streams

    # Pull row for this stream
    row = s[s["Stream"].astype(str) == str(stream)]
    if row.empty:
        return {}
    r = row.iloc[0]
    hits = int(r.get("HitsWindow", 0) or 0)
    hpw = float(r.get("HitsPerWeek", 0.0) or 0.0)
    dslh = int(r.get("DaysSinceLastHit", 0) or 0)

    # Due pressure as soft signal
    due_pressure = 0.0
    if in_due:
        due_pressure = float(dslh)

    # Optional 24h soft signal: add a small nudge if this core hit this stream in df_24
    if include_24h and df_24 is not None and not df_24.empty:
        try:
            cache_key = f"_nl_24h_corehits_{core}"
            if cache_key not in st.session_state:
                st.session_state[cache_key] = compute_core_hits(df_24, str(core), structures=["AABC"])
            df_24h_core_hits = st.session_state.get(cache_key, pd.DataFrame())
            if not df_24h_core_hits.empty and (df_24h_core_hits["Stream"].astype(str) == str(stream)).any():
                due_pressure += 1.0
        except Exception:
            pass

    seed_key = canonical_core_key(str(core))

    bucket_label = "Top12" if in_base else ("Due" if in_due else "")
    bucket_pick = "BASE" if in_base else ("DUE" if in_due else "")

    return {
        "Top12": bucket_label,
        "BucketPick": bucket_pick,
        "SeedKey": seed_key,
        "DuePressure": due_pressure,
        "HitsPerWeek": hpw,
        "Hits": hits,
        "DaysSinceLastHit": dslh,
    }




def get_pos_map_cached(core: str, window_days: int, stream_stats_df, last_date: str | None):
    k = f"pos_map::{window_days}::{str(core).zfill(3)}"
    if k in st.session_state:
        return st.session_state[k]
    # If stream_stats was loaded from disk, pos may already be in session_state
    pos_df = position_percentile_map(stream_stats_df)
    st.session_state[k] = pos_df
    # Save to disk alongside stream stats (best effort)
    try:
        _save_baseline_to_disk(core, window_days, stream_stats_df, pos_df, last_date)
    except Exception:
        pass
    return pos_df

# Baseline cache builder UI (runs only after history is loaded)
st.subheader("Baseline cache builder")
st.caption("This aggregates the Northern Star bucket picks across your selected cores and ranks them using a universal score (recent strength + due pressure + position-percentile strength).")

build_both = st.checkbox("Build cache for both windows (180 & 365)", value=False)
if st.button("Build baseline cache now"):
    if df_all is None or df_all.empty:
        st.warning("Upload a history file first.")
    else:
        build_windows = [180, 365] if build_both else [window_days]
        built = 0
        for w in build_windows:
            for c in cores_for_cache:
                stream_df = get_stream_stats_cached(c, w, df_all=df_all, last_date=last_all)
                pos_df = get_pos_map_cached(c, w, stream_df, last_date=last_all)
                try:
                    _save_baseline_to_disk(c, w, stream_df, pos_df, last_all)
                    built += 1
                except Exception:
                    pass
        st.success(f"Cache built for {built} core-window combinations. Latest history date: {last_all}")


tab_labels = ["Northern Lights (Master playlist)", "Core view", "Backtest (optional)"]
tabs = st.tabs(tab_labels)

# --- Northern Lights master playlist (best -> worst across streams/cores) ---
with tabs[0]:
    st.subheader("Northern Lights master playlist")
    st.caption("This aggregates the Northern Star bucket picks across your selected cores and ranks them using a universal score (recent strength + due pressure + position-percentile strength). Performance note: running across many cores can be slow; use the button below and/or build the baseline cache first.")
    # Build a stable key for the current Northern Lights inputs (prevents stale cached tables when inputs change).
    c1, c2 = st.columns([1, 2])
    with c1:
        run_now = st.button("Run / refresh Northern Lights now", type="primary", use_container_width=True)
    with c2:
        nl_autorun = st.checkbox("Auto-run when inputs change", value=False, help="Runs automatically when you change controls above. If off, use the Run button.")

    nl_key_payload = {
        "cores": list(cores_for_cache),
        "window_days": int(cfg.window_days),
        "exclude_md": bool(exclude_md),
        "last_all": (str(pd.to_datetime(last_all).date()) if ("last_all" in globals() and last_all is not None and not pd.isna(last_all)) else ""),
        "last_24h": (str(pd.to_datetime(last_24h).date()) if ("last_24h" in locals() and last_24h is not None and not pd.isna(last_24h)) else ""),
        "rare": {"R1": bool(r1), "R2": bool(r2), "R3": bool(r3), "R4": bool(r4)},
        "quad": {"Q1": bool(q1), "Q2": bool(q2), "Q3": bool(q3), "Q4": bool(q4)},
        "straights_opt": bool(straights_opt),
    }
    nl_key = hashlib.md5(json.dumps(nl_key_payload, sort_keys=True).encode("utf-8")).hexdigest()

    if st.session_state.get("_nl_key") != nl_key:
        st.session_state["_nl_key"] = nl_key
        st.session_state.pop("_nl_master", None)
        st.session_state.pop("_nl_plays", None)

    compute_now = nl_autorun or run_now

    if compute_now:
        rows = []
        prog = st.progress(0)
        status = st.empty()

        for idx, core in enumerate(cores):
            status.text(f"Computing Northern Lights for core {core} ({idx+1}/{len(cores)})…")

            stats = compute_stream_stats(df_all, core, cfg.window_days, exclude_md)
            if stats.empty:
                prog.progress((idx + 1) / max(1, len(cores)))
                continue

            # Position percentile map (cached on disk where possible)
            pos_map = get_pos_map_cached(core, cfg.window_days, stats, last_date=last_all)

            # Build a row per stream for this core
            for _, r in stats.iterrows():
                stream = str(r.get("Stream", ""))

                buckets = build_northern_star_buckets(
                    stats_df=stats,
                    stream=stream,
                    top_n=int(cfg.top12),
                    due_ranks=(int(cfg.due_ranks[0]), int(cfg.due_ranks[1])),
                    seed_core_key=cfg.seed_core_key,
                    include_24h=bool(cfg.include_24h_signals),
                    df_24=df_24,
                    core=core,
                )

                base_top = buckets.get("Top12")
                bucket_pick = buckets.get("BucketPick")
                seed_key = buckets.get("SeedKey")
                due_pressure = float(buckets.get("DuePressure", 0.0) or 0.0)
                rec = float(buckets.get("HitsPerWeek", 0.0) or 0.0)
                hits = int(buckets.get("Hits", 0) or 0)
                dslh = int(buckets.get("DaysSinceLastHit", 0) or 0)

                # Position strength (0..100) for this stream (if available)
                pos_strength = 0.0
                if pos_map is not None and not pos_map.empty and "PosStrength" in pos_map.columns:
                    m = pos_map[pos_map["Stream"] == stream]
                    if not m.empty:
                        pos_strength = float(m.iloc[0]["PosStrength"])

                # Universal score (keep same intent as before; just computed lazily now)
                master = (rec * 100.0) + due_pressure + (pos_strength * float(cfg.pos_strength_weight))

                rows.append(
                    {
                        "MasterScore": round(master, 2),
                        "PosStrength": round(pos_strength, 2),
                        "Core": int(core),
                        "Stream": stream,
                        "SeedKey": seed_key,
                        "Bucket": str(base_top),
                        "Hits": hits,
                        "HitsPerWeek": round(rec, 4),
                        "DaysSinceLastHit": dslh,
                        "DuePressure": round(due_pressure, 2),
                    }
                )

            prog.progress((idx + 1) / max(1, len(cores)))

        prog.empty()
        status.empty()

        df_master = pd.DataFrame(rows)
        if not df_master.empty:
            df_master = df_master.sort_values(["MasterScore", "PosStrength"], ascending=[False, False]).reset_index(drop=True)
            df_master.insert(0, "Rank", df_master.index + 1)

        st.session_state["_nl_master"] = df_master

        # Member-level scored plays (box members for each core)
        play_rows = []
        for _, rr in df_master.iterrows():
            core = int(rr["Core"])
            stream = str(rr["Stream"])
            seed_key = str(rr["SeedKey"])
            master = float(rr["MasterScore"])
            pos_strength = float(rr.get("PosStrength", 0.0))

            members = members_from_core(str(core).zfill(3), "AABC")
            for box in members:
                # Optional: if 24h file present, annotate if it appears in that stream's last 24h set
                in_24h = 0
                if df_24 is not None and not df_24.empty:
                    try:
                        in_24h = int(((df_24["Stream"] == stream) & (df_24["Box"] == box)).any())
                    except Exception:
                        in_24h = 0

                play_rows.append(
                    {
                        "MasterScore": master,
                        "PosStrength": pos_strength,
                        "Core": core,
                        "Stream": stream,
                        "Box": box,
                        "SeedKey": seed_key,
                        "In24h": in_24h,
                    }
                )

        df_plays = pd.DataFrame(play_rows)
        if not df_plays.empty:
            df_plays = df_plays.sort_values(["MasterScore", "PosStrength", "In24h"], ascending=[False, False, False]).reset_index(drop=True)
            df_plays.insert(0, "Rank", df_plays.index + 1)

        st.session_state["_nl_plays"] = df_plays

    # Display cached results (if available)
    df_master_show = st.session_state.get("_nl_master")
    if df_master_show is None:
        st.info("Click **Run / refresh Northern Lights now** to compute the master playlist.")
    elif df_master_show.empty:
        st.warning("No Northern Lights rows were generated. Check that your history file contains those cores/streams.")
    else:
        st.dataframe(df_master_show.head(int(cfg.max_master_rows)), use_container_width=True, hide_index=True)

    st.divider()

    st.subheader("Member-level scored plays (Northern Lights)")
    df_plays_show = st.session_state.get("_nl_plays")
    if df_plays_show is None:
        st.info("Run Northern Lights first to generate the scored member list.")
    elif df_plays_show.empty:
        st.warning("No member-level plays were generated.")
    else:
        st.dataframe(df_plays_show.head(int(cfg.max_final_rows)), use_container_width=True, hide_index=True)
        csv_bytes = df_plays_show.to_csv(index=False).encode("utf-8")
        st.download_button(
            "Download Final Scored Plays CSV",
            data=csv_bytes,
            file_name=f"northern_lights_scored_plays_{cfg.window_days}d.csv",
            mime="text/csv",
        )
with tabs[1]:
    st.subheader("Core view")
    if df_all is None or df_all.empty:
        st.info("Upload a history file to view per-core rankings.")
    else:
        # Let the user pick a single core to inspect (even if you selected many for Northern Lights)
        core_for_view = st.selectbox("Choose a core", cores, index=0, key="core_view_pick")
        stats = get_stream_stats_cached(core_for_view, cfg.window_days, df_all=df_all, last_date=last_all)
        st.markdown("#### Stream ranking (AABC doubles)")
        st.dataframe(
            stats[["RankPos", "Stream", "HitsWindow", "HitsPerWeek", "DaysSinceLastHit"]],
            use_container_width=True,
            height=460,
        )
        buckets = bucket_recommendations(stats, cfg)
        st.markdown("#### Northern Star buckets")
        c1, c2, c3 = st.columns(3)
        with c1:
            st.write("Top 12 (BaseScore)")
            st.write(buckets["base_top"])
        with c2:
            st.write("Due 8 (DueIndex)")
            st.write(buckets["due_top"])
        with c3:
            st.write("Combined (Top+Due)")
            st.write(buckets["combined"])
        st.caption("Core view uses the same window setting as the rest of the app. Switch 180/365 in the sidebar to compare.")

with tabs[2]:
    st.subheader("Backtest (optional)")
    st.caption(
        "This simulates a day-by-day run: for each test date, the app builds a playlist using history up through the prior day, "
        "then checks whether that date’s winners would have appeared in your Top-N plays for their streams. "
        "(This is compute-heavy, so keep the date range small.)"
    )

    enable_bt = st.checkbox("Enable backtest tools", value=False)
    if enable_bt:
        # Backtest settings
        top_n = st.selectbox("Count as a hit if winner is within Top-N plays (per stream)", [5, 10, 20, 40], index=1)

        all_streams_bt = sorted(df_all["Stream"].dropna().unique().tolist())
        bt_streams = st.multiselect("Limit backtest to streams (optional)", options=all_streams_bt, default=[])
        if bt_streams:
            st.caption(f"Backtest will score only winners inside {len(bt_streams)} selected streams.")
        else:
            st.caption("Backtest will score winners across ALL streams in the file (minus any global exclusions).")

        # Date range defaults: last 14 days (or as much as available)
        dates_all = sorted(df_all["Date"].dropna().unique())
        if len(dates_all) < 3:
            st.warning("Not enough dated history rows to run a backtest.")
        else:
            max_dt = pd.to_datetime(dates_all[-1])
            min_dt = pd.to_datetime(dates_all[0])
            max_d = max_dt.date()
            min_d = min_dt.date()
            default_start = max(min_d, (max_dt - pd.Timedelta(days=14)).date())

            d_start, d_end = st.slider(
                "Test date range",
                min_value=min_d,
                max_value=max_d,
                value=(default_start, max_d),
            )

            st.caption(
                "Tip: If you also upload a 24h map file, the app uses it for the *current day* view. "
                "For backtests, the app will automatically treat the prior day in your history as the ‘24h’ reference."
            )

            def _build_plays_for_training(df_train: pd.DataFrame, last_train_date: pd.Timestamp) -> pd.DataFrame:
                """Build the Northern Lights FinalScore play table using df_train only (no on-disk cache)."""
                # core list follows current UI selection (ALL = your multiselect list)
                selected_cores = [view_core] if view_core != "ALL" else cores_mult
                if not selected_cores:
                    return pd.DataFrame()

                # Compute per-core stream stats (AABC doubles)
                core_stats_local: dict[str, pd.DataFrame] = {}
                core_pos_local: dict[str, pd.DataFrame] = {}
                for _core in selected_cores:
                    st_stats = compute_stream_stats(df_train, _core, window_days=cfg.window_days, exclude_md=exclude_md)
                    core_stats_local[_core] = st_stats
                    core_pos_local[_core] = position_percentile_map(st_stats, _core)

                # Expand to member-level plays
                play_rows_local = []
                for _core, st_stats in core_stats_local.items():
                    if st_stats.empty:
                        continue
                    pos_map = core_pos_local.get(_core, pd.DataFrame())
                    members = members_from_core(_core, "AABC")
                    if not members:
                        continue

                    # Select bucket streams (Top 12 + Due ranks 13-60)
                    buckets = bucket_recommendations(st_stats, cfg)
                    stream_set = set(buckets["combined"])  # combined already preserves Top12 + DueTop

                    for row in st_stats.itertuples(index=False):
                        stream = getattr(row, "Stream")
                        rankpos = int(getattr(row, "RankPos"))
                        if stream not in stream_set:
                            continue

                        if bt_streams and stream not in bt_streams:
                            continue

                        # choose which bucket label
                        bucket = "Top12" if rankpos <= 12 else ("Due13_60" if 13 <= rankpos <= 60 else "Other")

                        # position percentile for that rankpos
                        pos_pct = np.nan
                        if not pos_map.empty:
                            hit_row = pos_map[pos_map["RankPos"] == rankpos]
                            if not hit_row.empty:
                                pos_pct = float(hit_row.iloc[0]["HitCountPctile"])

                        # member-level hits/due within window
                        sub_stream = df_train[df_train["Stream"] == stream]

                        for member in members:
                            box = box_key(member)
                            sub = sub_stream[sub_stream["BoxKey4"] == box]
                            hits = int(len(sub))
                            last_hit = sub["Date"].max() if hits > 0 else pd.NaT
                            days_since = (last_train_date - last_hit).days if hits > 0 and pd.notna(last_hit) else np.nan
                            hits_per_week = hits / (cfg.window_days / 7.0)

                            play_rows_local.append({
                                "Core": _core,
                                "Stream": stream,
                                "Bucket": bucket,
                                "RankPos": rankpos,
                                "MemberBox": member,
                                "Box": box,
                                "StreamHitsPerWeek": float(getattr(row, "HitsPerWeek")),
                                "StreamDaysSinceLastHit": float(getattr(row, "DaysSinceLastHit")) if pd.notna(getattr(row, "DaysSinceLastHit")) else np.nan,
                                "PosHitCountPctile": pos_pct,
                                "MemberHitsPerWeek": hits_per_week,
                                "MemberDaysSinceLastHit": days_since,
                            })

                dfp = pd.DataFrame(play_rows_local)
                if dfp.empty:
                    return dfp

                # Universal percentiles
                dfp["StreamHitsPerWeekPct"] = dfp["StreamHitsPerWeek"].rank(pct=True) * 100.0
                dfp["StreamDuePct"] = dfp["StreamDaysSinceLastHit"].rank(pct=True) * 100.0
                dfp["StreamDuePct"] = dfp["StreamDuePct"].fillna(100.0)
                dfp["MemberHitsPerWeekPct"] = dfp["MemberHitsPerWeek"].rank(pct=True) * 100.0
                dfp["MemberDuePct"] = dfp["MemberDaysSinceLastHit"].rank(pct=True) * 100.0
                dfp["MemberDuePct"] = dfp["MemberDuePct"].fillna(100.0)

                pos_fill = float(dfp["PosHitCountPctile"].median()) if dfp["PosHitCountPctile"].notna().any() else 50.0
                dfp["PosPctFill"] = dfp["PosHitCountPctile"].fillna(pos_fill)

                # Match live weights
                w_stream_hits, w_stream_due = 0.30, 0.15
                w_pos, w_member_hits, w_member_due = 0.20, 0.20, 0.15
                dfp["FinalScore"] = (
                    w_stream_hits * dfp["StreamHitsPerWeekPct"] +
                    w_stream_due  * dfp["StreamDuePct"] +
                    w_pos         * dfp["PosPctFill"] +
                    w_member_hits * dfp["MemberHitsPerWeekPct"] +
                    w_member_due  * dfp["MemberDuePct"]
                ).round(2)

                # De-dup within stream by Box (keep max score)
                dfp = dfp.sort_values("FinalScore", ascending=False)
                dfp = dfp.groupby(["Stream", "Box"], as_index=False).agg({
                    "FinalScore": "max",
                    "Core": "first",
                    "MemberBox": "first",
                    "Bucket": "first",
                    "RankPos": "min",
                })

                return dfp

            run_bt = st.button("Run backtest now")
            if run_bt:
                with st.spinner("Running backtest…"):
                    # work with pandas timestamps
                    start_ts = pd.to_datetime(d_start)
                    end_ts = pd.to_datetime(d_end)

                    # test dates (must have a prior day)
                    unique_dates = sorted(pd.to_datetime(df_all["Date"].dropna().unique()))
                    test_dates = [d for d in unique_dates if start_ts <= d <= end_ts]
                    if len(test_dates) < 2:
                        st.warning("Pick a range with at least 2 dates.")
                    else:
                        rows = []
                        for test_date in test_dates:
                            # training data is strictly prior to test date
                            df_train = df_all[df_all["Date"] < test_date].copy()
                            if df_train.empty:
                                continue
                            last_train = df_train["Date"].max()

                            plays_train = _build_plays_for_training(df_train, last_train)
                            if plays_train.empty:
                                continue

                            winners = df_all[df_all["Date"] == test_date].copy()
                            if winners.empty:
                                continue

                            for w in winners.itertuples(index=False):
                                stream = getattr(w, "Stream")
                                if bt_streams and stream not in bt_streams:
                                    continue
                                result = getattr(w, "Result")
                                winner_box = box_key(result)

                                sub = plays_train[plays_train["Stream"] == stream].sort_values("FinalScore", ascending=False).reset_index(drop=True)
                                if sub.empty:
                                    continue
                                total = int(len(sub))
                                hit_rank = None
                                hit = False
                                try:
                                    idx = int(sub.index[sub["Box"] == winner_box][0])
                                    hit_rank = idx + 1
                                    hit = hit_rank <= int(top_n)
                                except Exception:
                                    hit_rank = None
                                    hit = False

                                rows.append({
                                    "TestDate": test_date.date(),
                                    "Stream": stream,
                                    "Winner": result,
                                    "WinnerBox": winner_box,
                                    "RankInPlays": hit_rank,
                                    f"InTop{top_n}": hit,
                                    "Candidates": total,
                                    "TrainingLastDate": last_train.date(),
                                })

                        df_bt = pd.DataFrame(rows)
                        if df_bt.empty:
                            st.warning("No backtest rows produced. Try a smaller range or confirm your history file has Stream + Result + Date.")
                        else:
                            hit_col = f"InTop{top_n}"
                            hit_rate = df_bt[hit_col].mean() * 100.0
                            st.metric("Overall hit-rate", f"{hit_rate:.1f}%")
                            st.caption("Note: Streams not covered by your selected cores are ignored (no candidates).")

                            st.dataframe(df_bt, use_container_width=True, hide_index=True)

                            bt_csv = df_bt.to_csv(index=False).encode("utf-8")
                            st.download_button(
                                "Download backtest results CSV",
                                data=bt_csv,
                                file_name=f"pk4_northern_lights_backtest_top{top_n}.csv",
                                mime="text/csv",
                            )

# --- Per-core tabs ---
for core, tab in zip(cores, tabs[2:]):
    with tab:
        st.subheader(f"Core {core}")

        # Base (AABC doubles) core hits + stream ranking
        stats = get_stream_stats_cached(core, cfg.window_days, df_all=df_all, last_date=last_all)
        pos_map = get_pos_map_cached(core, cfg.window_days, stats, last_date=last_all)
        top30_positions = top_dense_positions(pos_map, top_n=10)
        capture = None
        if not pos_map.empty and pos_map["HitCount"].sum() > 0:
            capture = pos_map[pos_map["RankPos"].isin(top30_positions)]["HitCount"].sum() / pos_map["HitCount"].sum() * 100.0

        # Bucket recommendations
        buckets = bucket_recommendations(stats, cfg)

        left, right = st.columns([1.3, 1.0])

        with left:
            st.markdown("### Stream ranking (AABC doubles)")
            show = stats[["RankPos","Stream","HitsWindow","HitsPerWeek","DaysSinceLastHit"]].copy()
            show = show.rename(columns={
                "HitsWindow":"Hits",
                "HitsPerWeek":"Hits/week",
                "DaysSinceLastHit":"Days since last hit",
            })
            st.dataframe(show, use_container_width=True, hide_index=True)

        with right:
            st.markdown("### Northern Star buckets")
            st.write("**Top 12 (BaseScore)**")
            st.write("\n".join([f"- {s}" for s in buckets["base_top"]]) if buckets["base_top"] else "_None_")

            st.write("**Top 8 DueIndex (Ranks 13–60)**")
            st.write("\n".join([f"- {s}" for s in buckets["due_top"]]) if buckets["due_top"] else "_None_")

            st.write("**Combined list**")
            st.write("\n".join([f"- {s}" for s in buckets["combined"]]) if buckets["combined"] else "_None_")

            if straights_opt:
                st.markdown("### Straights shortlist (optional last)")
                straights_source = st.radio(
                    "Build straights from:",
                    [
                        "Northern Lights (final scored plays) — recommended",
                        "Core members only (legacy)",
                    ],
                    index=0,
                    horizontal=False,
                    help=(
                        "Recommended: expands the top Northern Lights box plays into straights and ranks them by real historical ordering frequency "
                        "in each stream (fallback to global history if needed). "
                        "Legacy: expands AABC core members without stream-specific ranking."
                    ),
                )

                if straights_source.startswith("Northern Lights"):
                    if "df_plays" not in locals() or df_plays is None or df_plays.empty:
                        st.info("Run Northern Lights first so the final scored plays table exists, then enable straights.")
                    else:
                        score_col = (
                            "MasterScore" if "MasterScore" in df_plays.columns
                            else ("FinalScore" if "FinalScore" in df_plays.columns else ("Score" if "Score" in df_plays.columns else None))
                        )
                        if score_col is None:
                            score_col = df_plays.columns[0]

                        c1, c2, c3 = st.columns(3)
                        with c1:
                            top_boxes = st.number_input("Expand top N box plays", min_value=1, max_value=250, value=25, step=1)
                        with c2:
                            per_box_topk = st.number_input("Keep top K straights per box", min_value=1, max_value=24, value=6, step=1)
                        with c3:
                            min_stream_hits = st.number_input(
                                "Min historical hits in stream to rank (else fallback to global)",
                                min_value=0, max_value=9999, value=1, step=1
                            )

                        global_counts = _value_counts_result(df_all)

                        df_expand = df_plays.sort_values(score_col, ascending=False).head(int(top_boxes)).copy()
                        streams_needed = (
                            sorted(df_expand["Stream"].dropna().astype(str).unique().tolist())
                            if "Stream" in df_expand.columns else []
                        )

                        stream_counts_map: dict[str, pd.Series] = {}
                        for s in streams_needed:
                            try:
                                stream_counts_map[s] = _get_stream_result_counts(df_all, s)
                            except Exception:
                                stream_counts_map[s] = pd.Series(dtype=int)

                        rows = []
                        for _, r in df_expand.iterrows():
                            stream = str(r.get("Stream", ""))
                            box4 = str(r.get("MemberBox", r.get("BoxPlay", "")))
                            if not box4:
                                continue

                            perms = unique_straights_for_box(box4)
                            if not perms:
                                continue

                            stream_counts = stream_counts_map.get(stream, pd.Series(dtype=int))
                            perm_stream_hits = [int(stream_counts.get(p, 0)) for p in perms]
                            box_stream_total = int(sum(perm_stream_hits))
                            use_global = box_stream_total < int(min_stream_hits)

                            if use_global:
                                perm_rank_hits = [int(global_counts.get(p, 0)) for p in perms]
                                rank_label = "global"
                            else:
                                perm_rank_hits = perm_stream_hits
                                rank_label = "stream"

                            order = sorted(
                                range(len(perms)),
                                key=lambda i: (perm_rank_hits[i], perm_stream_hits[i]),
                                reverse=True
                            )

                            for rank_i, i in enumerate(order[: int(per_box_topk)], start=1):
                                p = perms[i]
                                sh = int(perm_stream_hits[i])
                                gh = int(global_counts.get(p, 0))
                                pct = (sh / box_stream_total * 100.0) if box_stream_total > 0 else 0.0
                                rows.append({
                                    "Core": r.get("Core", ""),
                                    "Stream": stream,
                                    "BoxPlay": box4,
                                    score_col: r.get(score_col, None),
                                    "Bucket": r.get("Bucket", ""),
                                    "Straight": p,
                                    "StraightRank": rank_i,
                                    "RankSource": rank_label,
                                    "StreamHits_3yr": sh,
                                    "BoxHits_3yr": box_stream_total,
                                    "StraightPctOfBox": round(pct, 2),
                                    "GlobalHits_3yr": gh,
                                })

                        df_straights = pd.DataFrame(rows)
                        if df_straights.empty:
                            st.info("No straights were generated (check your Top N / file inputs).")
                        else:
                            df_straights = df_straights.sort_values(
                                [score_col, "Stream", "BoxPlay", "StraightRank"],
                                ascending=[False, True, True, True],
                            ).reset_index(drop=True)

                            st.caption(
                                "For each box play, we generate all unique straight permutations and rank them by "
                                "real historical ordering frequency in that stream (fallback to global history if needed)."
                            )
                            st.dataframe(df_straights, use_container_width=True, height=420)

                            st.download_button(
                                "Download Straights Shortlist CSV",
                                data=df_straights.to_csv(index=False).encode("utf-8"),
                                file_name="pk4_straights_shortlist.csv",
                                mime="text/csv",
                                use_container_width=True,
                            )
                else:
                    members = members_from_core(core, "AABC")
                    st.caption("Legacy: all unique permutations for each AABC core member (not stream-frequency ranked).")
                    rows = []
                    for m in members:
                        perms = unique_straights_for_box(m)
                        for p in perms:
                            rows.append({"Core": core, "BoxPlay": m, "Straight": p})
                    df_straights = pd.DataFrame(rows)
                    st.dataframe(df_straights, use_container_width=True, height=420)
                    st.download_button(
                        "Download Core Straights CSV (legacy)",
                        data=df_straights.to_csv(index=False).encode("utf-8"),
                        file_name=f"pk4_core_{core}_straights_legacy.csv",
                        mime="text/csv",
                        use_container_width=True,
                    )

        st.divider()

        with st.expander("Northern Star percentile stats (rank‑position map 1..N)", expanded=False):
            st.caption("Each position is labeled individually. 'Top30' is the Top‑10 positions by winner count in this window.")
            if pos_map.empty:
                st.info("No data for this core in the selected window.")
            else:
                st.write(f"**Top30 positions (Top‑10 by HitCount):** {top30_positions}")
                if capture is not None:
                    st.write(f"**Top30 capture rate:** {capture:.1f}% of hits in the window")
                st.dataframe(pos_map, use_container_width=True, hide_index=True)

        st.divider()

        # Rare Engine panel
        st.markdown("## Rare Engine — AAAB + AABB")
        rare_tbl, rare_summary = evaluate_rare_engine(
            df_all=df_all,
            core=core,
            df_24h=df_24h,
            enable_r1=r1, enable_r2=r2, enable_r3=r3, enable_r4=r4,
            window_days_recent=cfg.window_days
        )

        c1, c2 = st.columns(2)
        with c1:
            st.caption("Trigger rule: at least **3** enabled checks must be TRUE (per stream).")
            if "error" in rare_summary:
                st.error(rare_summary["error"])
            else:
                st.write(f"R1 threshold (top‑20% baseline): **{rare_summary['thr_r1']:.4f} hits/week**")
                st.write(f"R2 threshold (top‑20% recent): **{rare_summary['thr_r2']:.4f} hits/week**")
                st.write(f"R3 global (24h ≥3 hits across ≥3 streams): **{rare_summary['r3_global']}**")
                st.write(f"R4 Top‑10 cluster positions (24h): **{rare_summary['top10_cluster_positions']}**")
                st.write(f"24h core hits: **{rare_summary['n_24h_core_hits']}** across **{rare_summary['n_24h_core_streams']}** streams")

        with c2:
            # Quick readout: which streams fire?
            if not rare_tbl.empty:
                trig_streams = rare_tbl.loc[rare_tbl["RareEngine_TRIG"], "Stream"].tolist()
                st.write("**Streams where Rare Engine fires:**")
                st.write("\n".join([f"- {s}" for s in trig_streams]) if trig_streams else "_None_")

                st.write("**When it fires, add these boxes:**")
                members = members_from_core(core, "AAAB") + members_from_core(core, "AABB")
                boxes = sorted(set(box_key(m) for m in members))
                st.write(", ".join(boxes))
            else:
                st.info("No rare-engine table yet.")

        if not rare_tbl.empty:
            cols = ["Stream","RankPos_full","HitsPerWeek_full","HitsPerWeek","DaysSinceLastHit",
                    "R1_top20_baseline","R2_top20_recent","R3_24h_has_3plus_across_3streams","R4_24h_cluster_top10pos",
                    "ChecksTrue","RareEngine_TRIG"]
            view = rare_tbl[cols].copy()
            view = view.rename(columns={
                "RankPos_full":"RankPos (baseline)",
                "HitsPerWeek_full":"Baseline hits/week",
                "HitsPerWeek":"Recent hits/week",
                "DaysSinceLastHit":"Days since last rare hit",
                "R1_top20_baseline":"R1",
                "R2_top20_recent":"R2",
                "R3_24h_has_3plus_across_3streams":"R3 (24h ≥3 hits/≥3 streams)",
                "R4_24h_cluster_top10pos":"R4",
                "ChecksTrue":"# checks TRUE",
                "RareEngine_TRIG":"RARE ENGINE",
            })
            st.dataframe(view, use_container_width=True, hide_index=True)

        st.divider()

        # Ultra-rare engine panel
        st.markdown("## Ultra‑Rare — Quads (AAAA)")
        ultra_tbl, ultra_summary = evaluate_ultra_rare_engine(
            df_all=df_all,
            core=core,
            df_24h=df_24h,
            enable_q1=q1, enable_q2=q2, enable_q3=q3, enable_q4=q4
        )

        u1, u2 = st.columns(2)
        with u1:
            st.caption("Trigger rule: at least **2** enabled checks must be TRUE (per stream).")
            if "error" in ultra_summary:
                st.error(ultra_summary["error"])
            else:
                st.write(f"Q1 threshold (top‑10% baseline): **{ultra_summary['thr_q1']:.4f} hits/week**")
                st.write(f"Q2 threshold (P90 due): **{ultra_summary['thr_q2']:.0f} days**")
                st.write(f"Q3 24h quad exists (core digits): **{ultra_summary['q3_global']}**")
                st.write(f"Q4 Top‑5 cluster positions (24h): **{ultra_summary['top5_cluster_positions']}**")
                st.write(f"24h core quad hits: **{ultra_summary['n_24h_core_quad_hits']}**")

        with u2:
            if not ultra_tbl.empty:
                trig_streams = ultra_tbl.loc[ultra_tbl["UltraRare_TRIG"], "Stream"].tolist()
                st.write("**Streams where Ultra‑Rare fires:**")
                st.write("\n".join([f"- {s}" for s in trig_streams]) if trig_streams else "_None_")
                st.write("**When it fires, add these quad boxes:**")
                q_members = members_from_core(core, "AAAA")
                st.write(", ".join(sorted(set(box_key(m) for m in q_members))))
            else:
                st.info("No ultra-rare table yet.")

        if not ultra_tbl.empty:
            cols = ["Stream","RankPos_full","HitsPerWeek_full","DaysSinceLastHit",
                    "Q1_top10_baseline","Q2_due_p90","Q3_24h_quad_exists","Q4_24h_cluster_top5pos",
                    "ChecksTrue","UltraRare_TRIG"]
            view = ultra_tbl[cols].copy()
            view = view.rename(columns={
                "RankPos_full":"RankPos (baseline)",
                "HitsPerWeek_full":"Baseline hits/week",
                "DaysSinceLastHit":"Days since last quad",
                "ChecksTrue":"# checks TRUE",
                "UltraRare_TRIG":"ULTRA‑RARE",
            })
            st.dataframe(view, use_container_width=True, hide_index=True)

        st.caption("Tip: Quads are extremely sparse. Use Ultra‑Rare as a *bonus watch*—not a daily expectation.")